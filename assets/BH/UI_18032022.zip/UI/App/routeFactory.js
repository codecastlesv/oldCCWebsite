﻿var app = angular.module('app');

app.config(function ($routeProvider, $locationProvider) {
    var baseUrl = "app/views/";

    $routeProvider.when('/', {
        templateUrl: baseUrl + 'home.html?v=' + guid(),
        controller: 'AppController',
    });

    $routeProvider.when('/Roles', {
        templateUrl: baseUrl + 'roles/index.html?v=' + guid(),
        controller: 'rolesController',
    });

    $routeProvider.when('/Users', {
        templateUrl: baseUrl + 'users/index.html?v=' + guid(),
        controller: 'userscontroller',
    });


    $routeProvider.when('/Farms', {
        templateUrl: baseUrl + 'farms/index.html?v=' + guid(),
        controller: 'farmscontroller',
    });

    $routeProvider.when('/NewFarms', {
        templateUrl: baseUrl + 'farms/newFarm.html?v=' + guid(),
        controller: 'farmscontroller',
    });


    $routeProvider.when('/Collaborators', {
        templateUrl: baseUrl + 'collaborators/index.html?v=' + guid(),
        controller: 'collaboratoscontroller',
    });

    $routeProvider.when('/Crops', {
        templateUrl: baseUrl + 'crops/index.html?v=' + guid(),
        controller: 'cropscontroller',
    });

    $routeProvider.when('/CropRecord', {
        templateUrl: baseUrl + 'crops/CropRecord.html?v=' + guid(),
        controller: 'cropscontroller',
    });

    $routeProvider.when('/ListCropRecord', {
        templateUrl: baseUrl + 'crops/ListCropRecord.html?v=' + guid(),
        controller: 'cropscontroller',
    });

    $routeProvider.when('/FormCustomer', {
        templateUrl: baseUrl + 'customers/index.html?v=' + guid(),
        controller: 'customercontroller',
    });

    $routeProvider.when('/ListCustomer', {
        templateUrl: baseUrl + 'customers/ListCustomer.html?v=' + guid(),
        controller: 'customercontroller',
    });

    $routeProvider.when('/DiseasesPlague', {
        templateUrl: baseUrl + 'diseasesPlague/index.html?v=' + guid(),
        controller: 'diseasesPlagueController',
    });


    $routeProvider.when('/FarmDiseasesPlague', {
        templateUrl: baseUrl + 'diaseasePlagueFarm/index.html?v=' + guid(),
        controller: 'diseasesPlagueController',
    });

    $routeProvider.when('/FarmDiseasesPlagueList', {
        templateUrl: baseUrl + 'diaseasePlagueFarm/ListPlagueFarm.html?v=' + guid(),
        controller: 'farmPlagueController',
    });

    $routeProvider.when('/DiseasesPlagueCategory', {
        templateUrl: baseUrl + 'diseasesCategory/index.html?v=' + guid(),
        controller: 'diseasesPlagueController',
    });

    $routeProvider.when('/CreateTask', {
        templateUrl: baseUrl + 'task/NewTask.html?v=' + guid(),
        controller: 'taskcontroller',
    });

    $routeProvider.when('/ListTasks', {
        templateUrl: baseUrl + 'task/index.html?v=' + guid(),
        controller: 'taskcontroller',
    });

    $routeProvider.when('/Details', {
        templateUrl: baseUrl + 'details/index.html?v=' + guid(),
        controller: 'dashboardcontroller',
    });

    $routeProvider.when('/MyTasks', {
        templateUrl: baseUrl + 'task/myTask.html?v=' + guid(),
        controller: 'taskcontroller',
    });

    $routeProvider.when('/Maps', {
        templateUrl: baseUrl + 'map/index.html?v=' + guid(),
        controller: 'mapsController',
    });

    $routeProvider.when('/ListMap', {
        templateUrl: baseUrl + 'map/ListMapRecord.html?v=' + guid(),
        controller: 'mapsController',
    });

    $routeProvider.when('/CustomerInformation', {
        templateUrl: baseUrl + 'customers/information.html?v=' + guid(),
        controller: 'customercontroller',
    });

    $routeProvider.when('/NewMap', {
        templateUrl: baseUrl + 'map/NewMap.html?v=' + guid(),
        controller: 'mapsController',
    });

    $routeProvider.when('/Reportes', {
        templateUrl: baseUrl + 'reports/index.html?v=' + guid(),
        controller: 'reportscontroller',
    });

    $routeProvider.when('/Reportes/TechnicalForm', {
        templateUrl: baseUrl + 'reports/technicalform.html?v=' + guid(),
        controller: 'reportscontroller',
    });

    $routeProvider.when('/Reportes/FarmData', {
        templateUrl: baseUrl + 'reports/farmDetailReport.html?v=' + guid(),
        controller: 'reportscontroller',
    });

    $routeProvider.when('/Reportes/MapData', {
        templateUrl: baseUrl + 'reports/mapDetailReport.html?v=' + guid(),
        controller: 'reportscontroller',
    });

    $routeProvider.when('/Reportes/CropData', {
        templateUrl: baseUrl + 'reports/cropDetailReport.html?v=' + guid(),
        controller: 'reportscontroller',
    });

    $routeProvider.when('/Reportes/VisitData', {
        templateUrl: baseUrl + 'reports/visitDetailReport.html?v=' + guid(),
        controller: 'reportscontroller',
    });

    $routeProvider.when('/Reportes/DownloadTechnicalForm', {
        templateUrl: baseUrl + 'reports/downloadtechnicalform.html?v=' + guid(),
        controller: 'reportscontroller',
    });

    $routeProvider.when('/Reportes/TechnicalProfile', {
        templateUrl: baseUrl + 'reports/visitTechnicalProfile.html?v=' + guid(),
        controller: 'reportscontroller',
    });
    // use the HTML5 History API
    //$locationProvider.html5Mode(true);
});