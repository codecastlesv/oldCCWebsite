﻿var app = angular.module("app");
app.factory("interceptor", function ($location, $rootScope) {
    return {
        'responseError': function (response) {
            if (response.status === 401) {
                $location.path("/");
            }
            return response;
        }
    };
});

app.config(function ($httpProvider) {
    $httpProvider.interceptors.push('interceptor');
});

app.service("authorizationService", function ($http, $rootScope) {
    function getConfig() {
        if (!$rootScope.user) return {};
        var config = {
            headers: {
                "Authorization": "Bearer " + $rootScope.user.access_token
            }
        };
        return config;
    }
    var me = this;
    var apiURL = window.location.protocol + "//" +
        window.location.host +
        (window.location.host.indexOf(":") != -1 ? "" : (window.location.port ? ":" + window.location.port : "")) +
        window.location.pathname;
    apiURL = apiURL.toUpperCase().split("ACCOUNT")[0].toLocaleLowerCase();
    apiURL += 'api/account/';

    me.login = function (userName, password) {
        var entity = {
            Email: userName,
            Password: password
        };

        return $http.post(apiURL + "login", entity);
    };

    me.logout = function () {
        localStorage.clear();
        return $http.post(apiURL + "logout");
    }
}
);

var app = angular.module("app");
app.factory("interceptor", function ($location, $rootScope) {
    return {
        'responseError': function (response) {
            if (response.status === 401) {
                $location.path("/");
            }
            return response;
        }
    };
});
app.config(function ($httpProvider) {
    $httpProvider.interceptors.push('interceptor');
});

app.service("authorizationService", function ($http, $rootScope) {
    function getConfig() {
        if (!$rootScope.user) return {};
        var config = {
            headers: {
                "Authorization": "Bearer " + $rootScope.user.access_token
            }
        };
        return config;
    }
    var me = this;
    var apiURL = window.location.protocol + "//" +
        window.location.host +
        (window.location.host.indexOf(":") != -1 ? "" : (window.location.port ? ":" + window.location.port : "")) +
        window.location.pathname;
    apiURL = apiURL.toUpperCase().split("ACCOUNT")[0].toLocaleLowerCase();
    apiURL += 'api/account/';

    me.login = function (userName, password) {
        var entity = {
            Email: userName,
            Password: password
        };

        return $http.post(apiURL + "login", entity);
    };

    me.logout = function () {
        localStorage.clear();
        return $http.post(apiURL + "logout");
    }
}
);