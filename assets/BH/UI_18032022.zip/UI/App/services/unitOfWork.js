﻿var app = angular.module("app");
app.service("unitOfWork", ["$http", "$rootScope", "$timeout", "$location",
    function ($http, $rootScope, $q, $timeout) {

        function getConfig() {
            if (!$rootScope.user || !$rootScope.user.access_token) {
                if (window.localStorage.user) {
                    $rootScope.user = JSON.parse(window.localStorage.user);
                }
                else {
                    return {};
                }
            }
              
            return {
                // headers: { "Authorization": "Bearer " + $rootScope.user.access_token }
                headers: { "Authorization": "Bearer " + $rootScope.user.access_token }
            };
        };

        //REPOSITORIO DE DATOS headers: { "Authorization": "Basic" + $rootScope.user.access_token }
        function repository(controller) {
            var self = this;
            var apiURL = "api/";
            self.getAll = function (scope, propertyName, callback, errorCallback) {
                return $http.get(apiURL + controller, getConfig())
                    .success(function (response) {
                        if (!scope || !propertyName) return;
                        scope[propertyName] = response;

                        if (callback)
                            callback(response);
                    }).error(function (error) {
                        if (errorCallback)
                            errorCallback(error);
                    });
            };

            self.get = function (keys) {
                //return $http({ method: "get", url: apiURL + controller + "/" + keys.join("/"), async: true });

                return $http.get(apiURL + controller + "/" + keys.join("/"), getConfig());

            }

            self.post = function (keys, data) {
                return $http.post(apiURL + controller + "/" + keys.join("/"), data, getConfig());
            }

            self.put = function (keys, data) {
                return $http.put(apiURL + controller + "/" + keys.join("/"), data, getConfig());
            }

            self.delete = function (keys) {
                return $http.delete(apiURL + controller + "/" + keys.join("/"), getConfig());

            }

            self.getById = function (id) {
                return $http.get(apiURL + controller + "/" + id);
            };

            self.create = function (entity) {
                return $http.post(apiURL + controller, entity);
            };

            self.update = function (entity) {
                return $http.put(apiURL + controller, entity);
            };

            self.upload = function (keys, entity, callback, errorCallback) {
                var uploadUrl = apiURL + controller + "/" + keys.join("/");

                var xhr = new XMLHttpRequest();
                xhr.open('POST', uploadUrl, true);
                xhr.onload = function () {
                    if (xhr.status === 200) {
                        if (callback) {
                            callback(JSON.parse(xhr.response));
                        }
                    } else {
                        if (errorCallback) {
                            errorCallback(JSON.parse(xhr.response));
                        }
                    }
                };

                xhr.send(entity);
            };

            return self;
        }

        this.Roles = new repository("Roles");        
        this.Users = new repository("Users");
        this.Farms = new repository("Farms");
        this.Crops = new repository("Crops");
        this.Maps = new repository("Maps");
        this.Country = new repository("Country");
        this.DiseasesPlague = new repository("PlagueDiseases");
        this.Task = new repository("Task");
        this.DashboardData = new repository("DashboardData");
        this.Reports = new repository("Form");
    }
]);