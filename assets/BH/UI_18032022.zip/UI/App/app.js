﻿var app = angular.module("app", ["ngRoute", "ui.bootstrap", "datatables", "ui-leaflet", "chart.js"]);

app.controller("AppController", function ($scope, $filter, $rootScope, authorizationService, unitOfWork, $timeout) {

    if (typeof (localStorage.user) == 'undefined') {
        var url = window.location.protocol + "//" +
            window.location.host +
            (window.location.host.indexOf(":") != -1 ? "" : (window.location.port ? ":" + window.location.port : "")) +
            window.location.pathname;
        url = url.toUpperCase().split("ACCOUNT")[0].toLocaleLowerCase();
        //url = url + 'Account/login';
        url = url + 'Home/marketplace';
        window.location.href = url;
    } else {

     console.log(JSON.parse(localStorage.user));
    }

    $scope.date = new Date();
    $scope.user = $scope.user ? $scope.user : localStorage.user ? JSON.parse(localStorage.user) : null;
    $scope.UserData = $scope.user.user;
   // console.log(localStorage.user);


    function init() { 
        $scope.clock = "loading clock..."; // initialise the time variable
        $scope.tickInterval = 0 //ms
        var tick = function () {
            $scope.clock = Date.now() // get the current time            
            $timeout(tick, $scope.tickInterval); // reset the timer
        }

        var hours = new Date().getHours();
        $scope.ampm = hours >= 12 ? 'PM' : 'AM';

        // Start the timer
        $timeout(tick, $scope.tickInterval);

        $scope.getRoles();
    }

    $scope.getRoles = function () {
        $scope.listRoles = [];
        unitOfWork.Roles.get(["getRoles"]).then(function (response) {
            angular.forEach(response.data.model, function (value) {
                if (value.Id == $scope.user.user.Role_id) {
                    $scope.roleName = value.Name;
                }
            });
        });
    }

    $scope.myTask = function () {
        var id = $scope.UserData.id;
         unitOfWork.Task.get(["getMyTasksCalendar", id]).then(function (response) {
             localStorage.setItem("events", JSON.stringify(response.data.model));   
            // console.log(localStorage.getItem("events"));
         });
        window.location.href = "#!/MyTasks";
    }

    $scope.logOut = function () {
        var url = window.location.protocol + "//" +
            window.location.host +
            (window.location.host.indexOf(":") != -1 ? "" : (window.location.port ? ":" + window.location.port : "")) +
            window.location.pathname;
        url = url.toUpperCase().split("ACCOUNT")[0].toLocaleLowerCase();
        url = url + 'Account/login';
        localStorage.clear();
        window.location.href = url;
    }

    init();

});


function guid() {
    function s4() {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    }
    return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
};

// Custom interceptor factoring
app.factory('httpLoadingInterceptor', ['$q', '$rootScope', function ($q, $rootScope) {

    // Request iteration counter - count requests started
    var reqIteration = 0;
    return {
        request: function (config) {
            // Firing event only if current request was the first
            if (reqIteration === 0) {
                $rootScope.$broadcast('globalLoadingStart');
            }
            // Increasing request iteration
            reqIteration++;
            return config || $q.when(config);
        },
        response: function (config) {
            // Decreasing request iteration
            reqIteration--;
            // Firing event only if current response was came to the last request
            if (!reqIteration) {
                $rootScope.$broadcast('globalLoadingEnd');
            }
            return config || $q.when(config);
        }
    };
}])

// Injecting our custom loader interceptor
app.config(['$httpProvider', function ($httpProvider) {

    $httpProvider.interceptors.push('httpLoadingInterceptor');
}])

// Directive for loading
app.directive('ionLoader', function () {

    return {
        restrict: 'E',
        replace: true,
        template: '<div class="ion-loader"><svg class="ion-loader-circle"> <circle class="ion-loader-path" cx="50%" cy="50%" r="20" fill="none" stroke-miterlimit="10"/></svg></div>',
        link: function (scope, element) {

            // Applying base class to the element
            angular.element(element).addClass('ion-hide');

            // Listening to 'globalLoadingStart' event fired by interceptor on request sending
            scope.$on('globalLoadingStart', function () {
                //console.log("Loading started...");
                angular.element(element).toggleClass('ion-show ion-hide');
            });

            // Listening to 'globalLoadingEnd' event fired by interceptor on response receiving
            scope.$on('globalLoadingEnd', function () {
                //console.log("Loading ended...");
                angular.element(element).toggleClass('ion-hide ion-show');
            });
        }
    }
})

app.directive('uploadFiles', function () {
    return {
        scope: true,        //create a new scope  
        link: function (scope, el, attrs) {
            el.bind('change', function (event) {
                var files = event.target.files;
                //iterate files since 'multiple' may be specified on the element  
                for (var i = 0; i < files.length; i++) {
                    //emit event upward  
                    scope.$emit("seletedFile", { file: files[i] });
                }
            });
        }
    };
});

app.directive('fileModel', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {

            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;

            element.bind('change', function () {
                scope.$apply(function () {
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);

app.filter('sumByKey', function () {
    return function (data, key) {
        if (typeof (data) === 'undefined' || typeof (key) === 'undefined') {
            return 0;
        }

        var sum = 0;
        for (var i = data.length - 1; i >= 0; i--) {
            var valKey;
            if (data[i][key]) {
                valKey = parseFloat(data[i][key]);
            }
            else {
                valKey = 0;
            }
            sum += parseFloat(valKey);
        }

        return sum;
    };
});




