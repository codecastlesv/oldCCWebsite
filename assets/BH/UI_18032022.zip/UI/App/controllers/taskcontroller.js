﻿var app = angular.module('app');

app.controller('taskcontroller', function ($scope, $rootScope, $location, authorizationService, unitOfWork, $uibModal) {

    function init() {
        $scope.UserData = $scope.user.user; 
        $scope.UserSelected = '';
        $scope.save = false;

        //CARGAR FINCAS SEGUN ROL Y USUARIO
        if ($scope.UserData.id_rol == 6 || $scope.UserData.id_rol == 5) {
            $scope.getFarmsbyFarms($scope.UserData.id_rol, $scope.UserData.id);
            if ($scope.UserData.id_rol == 5) {
                $scope.getFarmTask($scope.UserData.id_rol,$scope.UserData.id);
            }        
        } else {         
            if ($scope.UserData.id_rol != 6 || $scope.UserData.id_rol != 5) {
                $scope.getFarms();
                $scope.getTask();
            }
        }


        //CARGA CALENDARIO DE COLABORADOR
        if ($scope.UserData.id_rol == 6) {
            $scope.getMyTask($scope.UserData.id);
            $scope.task_details= '';
        }
    }



    $scope.reflesh = function () {
        window.location.reload();
    }

    //RECARGAR CALENDARIO DE TAREAS ROL COLABORADOR
    $scope.loadtask = function () {
        window.location.reload();
    }

    //MUESTRA DETALLE DE CADA TAREA
    $scope.info = function (item) {
        $scope.task_details = item;
        $scope.fecha = moment(item.date_task).format('DD-MM-YYYY');
    }

    //LISTA DE FINCAS REGISTRADAS
    $scope.getFarms = function () {
        $scope.listFarms = [];
        unitOfWork.Farms.get(["getFarms"]).then(function (response) {
            $scope.listFarms = response.data.model;
        });
    }

    //LISTA DE FINCAS REGISTRADAS
    $scope.getFarmsbyFarms = function (rol, user) {
        $scope.listFarms = [];
        unitOfWork.Farms.get(["getFarmByRol",rol,user]).then(function (response) {
            $scope.listFarms = response.data.model;
        });
    }

    //LISTA DE TAREAS REGISTRADAS
    $scope.getTask = function () {
        $scope.listTask = [];
        unitOfWork.Task.get(["getTask",0]).then(function (response) {
            $scope.listTask = response.data.model;
        });
    }


    //LISTA DE TAREAS DE MI FINCAS - ROL ASOCIADO
    $scope.getFarmTask = function (rol,user) {
        $scope.listTask = [];
        unitOfWork.Task.get(["getTaskFarm",rol,user]).then(function (response) {
            $scope.listTask = response.data.model;
        });
    }

    //BUSCAR LOS COLABORADORES DE POR FINCA
    $scope.Select = function (item) {

        if (item > 0) {
            $scope.listusers = [];
            unitOfWork.Users.get(["getUserFarm", item]).then(function (response) {
                $scope.listusers = response.data.model;
            });
        } else {
            $scope.listusers = [];
        }
      
    }

    // POST FUNCION PARA GUARDAR UNA TAREA
    $scope.postTask = function () {
        var user = JSON.parse(localStorage.user);
        var creator = user.user;
        var range = $scope.data.assingment;
        var date_assigment = moment(range).format('YYYY-MM-DD')
        $scope.task = [];
        for (var i = 0; i < $scope.participant.length; i++) {
            $scope.task.push({
                username: $scope.participant[i].Name,
                Lastname: $scope.participant[i].Lastname,
                email: $scope.participant[i].email,
                id_farm: $scope.data.id_farm,
                name: $scope.data.name,
                description: $scope.data.description,
                date_task: date_assigment,
                id_creator: creator.id
            });   
        }
    
        unitOfWork.Task.post(["postTask"],$scope.task).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        });
    }

    // FUNCION PARA GUARDAR CAMBIOS DE DATA
    $scope.putTask = function () {
        console.log($scope.task);
        unitOfWork.Task.post(["putTask"], $scope.task).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        });
    }

    // FUNCION PARA ELIMINACION CAMPO BASE DE DATOS 
    $scope.deleteTask = function (item) {
        console.log(item);
        Swal.fire({
            title: '¡Aviso!',
            text: 'Desea eliminar esta tarea?',
            type: 'question',
            confirmButtonText: 'Si, Eliminar',
            confirmButtonColor: '#23B931',
            cancelButtonText: 'Cerrar',
            showCancelButton: true,
            cancelButtonColor: '#dc3545'
        }).then((result) => {
            if (result.value) {
                unitOfWork.Task.get(["getDestroy", item.id]).then(function (response) {
                    if (!response.data.hasError) {
                        Swal.queue([{
                            title: '¡Aviso!',
                            text: response.data.message,
                            confirmButtonText: 'Ok',
                            showLoaderOnConfirm: true,
                            preConfirm: () => {
                                window.location.reload();
                            }
                        }])
                    }
                });
            
            } else {
                $scope.closeModal()
               
            }
        });
    }
 
    //TRAE LAS TAREAS ASIGNADAS DEL COLABORADOR POR SU ID
    $scope.getMyTask = function (id) {
        unitOfWork.Task.get(["getMyTasksCalendar", id]).then(function (response) {
            localStorage.setItem("events", JSON.stringify(response.data.model));
        });

        $scope.listMyTask = [];
        unitOfWork.Task.get(["getMyTasks",id]).then(function (response) {
            $scope.listMyTask = response.data.model;
        });
    }

    //REPORTAR TAREA COMO TERMINADA 
    $scope.checkTask = function (item) {
       // console.log(item);

        Swal.fire({
            title: '¡Aviso!',
            text: 'Esta seguro de reporta ' + item.name + ' como tarea terminada?',
            type: 'question',
            confirmButtonText: 'Si, Estoy seguro',
            confirmButtonColor: '#23B931',
            cancelButtonText: 'Cerrar',
            showCancelButton: true,
            cancelButtonColor: '#dc3545'
        }).then((result) => {
            if (result.value) {
                unitOfWork.Task.get(["checkTask", item.id, $scope.UserData.id]).then(function (response) {
                    if (!response.data.hasError) {
                        Swal.queue([{
                            title: '¡Aviso!',
                            text: response.data.message,
                            confirmButtonText: 'Ok',
                            showLoaderOnConfirm: true,
                            preConfirm: () => {
                                window.location.reload();
                            }
                        }])
                    }
                });
            
            } else {
                $scope.closeModal()
                
            }
        });
  
    }

    // FUNCION PARA ELIMINAR USUARIO DE UNA TAREA REGISTRADA
    $scope.deleteTaskUser = function (item) {
        Swal.fire({
            title: '¡Aviso!',
            text: 'Se eliminara a '+item.Name+' de esta tarea?',
            type: 'question',
            confirmButtonText: 'Si, Eliminar',
            confirmButtonColor: '#23B931',
            cancelButtonText: 'Cerrar',
            showCancelButton: true,
            cancelButtonColor: '#dc3545'
        }).then((result) => {
            if (result.value) {
                unitOfWork.Task.get(["getDestroyTaskUser", item.id]).then(function (response) {
                    if (!response.data.hasError) {
                        Swal.queue([{
                            title: '¡Aviso!',
                            text: response.data.message,
                            confirmButtonText: 'Ok',
                            showLoaderOnConfirm: true,
                            preConfirm: () => {
                                window.location.reload();
                            }
                        }])
                    }
                });
              
            } else {
                $scope.closeModal()
               
            }
        });

    }
 
    // FUNCION DE DESPLIEGA MODAL PARA MODIFICAR TAREA
    $scope.modTask = function (item) {
      //  console.log(item);
        $scope.title = "Modificar tarea de " + item.farm;
        $scope.isUpdate = true;
        $scope.task= item;
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/task/modal.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        });
    }


    // FUNCION DE DESPLIEGA MODAL PARA VER USUARIOS ASIGNADOS EN UNA TAREA
    $scope.detail = function (item) {
        $scope.listusers = [];
        unitOfWork.Task.get(["getTaskUsers",item.id]).then(function (response) {
            $scope.listusers = response.data.model;
        });
        $scope.title = "Tarea:" + item.name;
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/task/ListUsers.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        });
    }


    //CAPTURAR USUARIO AL QUE SE ASIGNARA TAREA
    $scope.select = function (item) {

        $scope.UserSelected = JSON.parse(item);
    }
 

    //CREACION DE LISTA DE PARTICIPANTES DE TAREA A ASIGNAR
    $scope.participant = [];
    $scope.addUserTask = function (item) {
        var itemActual;
        for (var i = 0; i < $scope.participant.length; i++) {
            if ($scope.participant[i].id_user == item.id_user) {
                itemActual = $scope.participant[i];
            }
        }
        if (!itemActual) {
            $scope.participant.push({
                Name: item.Name,
                Lastname: item.Lastname,
                email:item.email,
                id_user: item.id_user
            });     
        }
    }
    //REMOVER USUARIO DE LAS LISTA DE PARTICIPANTES DE TAREA
    $scope.remover_participant = function (item) {
        for (var i = 0; i < $scope.participant.length; i++) {
            if ($scope.participant[i].id_user == item.id_user) {
                $scope.participant.splice(i, 1);
            }

        }
    }


    $scope.SelectUser = function (id) {
       // console.log(id);
        if (id > 0) {
            $scope.save = true;
        } else {
            $scope.save = false;
        }
    }


    $scope.saveUserTask = function () {
       
        $scope.taskUser.idTask = $scope.taskInfo.id;
        unitOfWork.Task.post(["PostColaboratorTask"], $scope.taskUser).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        });
    }


    $scope.addUserTaskTo = function (item) {
        var id = item.id_farms;
        $scope.listusersTask = [];
        unitOfWork.Users.get(["getUserFarm",id]).then(function (response) {
                $scope.listusersTask = response.data.model;
        });
        $scope.taskUser = {};
        $scope.title =  item.name +" - Finca "+ item.farm;
        $scope.isUpdate = true;
        $scope.taskInfo = item;
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/task/addUserTask.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        });
    }

    // FUNCION PARA CERRAR VENTA MODAL
    $scope.closeModal = function () {
        $rootScope.modalInstance.close();
    };

    init();
});