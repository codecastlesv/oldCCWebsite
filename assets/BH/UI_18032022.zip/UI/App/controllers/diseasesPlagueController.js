﻿var app = angular.module('app');

app.controller('diseasesPlagueController', function ($scope, $rootScope, $location, authorizationService, unitOfWork, $uibModal) {

    function init() {
        $scope.getDiseasesPlague();
        $scope.getCategory();
        $scope.userData = $scope.user.user;
        $scope.otherPlage = false;
        //CARGAR FINCAS SEGUN ROL Y USUARIO
        if ($scope.userData.id_rol == 6 || $scope.userData.id_rol == 5) {
            $scope.getFarmsbyFarms($scope.userData.id_rol, $scope.userData.id);
        } else {
            $scope.getFarms();
        }
        setTimeout(function () { toBase64(); }, 5000);

    }

    //FUNCION PARA RECARGAR PAGINA
    $scope.reflesh = function () {
        window.location.reload();
    }

    //FUNCION PARA TRAER TODAS LAS PLAGAS Y ENFERMEDADES
    $scope.getDiseasesPlague = function () {
        $scope.listDiseasesPlague = [];
        unitOfWork.DiseasesPlague.get(["getPlagueDiseases"]).then(function (response) {
            $scope.listDiseasesPlague = response.data.model;
        });
    }

    //LISTA LAS ENFEREDADES SEGUN LA OPCION DEL SELECT DE CATEGORIA
    $scope.getDiseasesPlagueC = function (id) {
        $scope.listDiseasesPlague2 = [];
        unitOfWork.DiseasesPlague.get(["getPlagueDiseasesC",id]).then(function (response) {
            $scope.listDiseasesPlague2 = response.data.model;
        });
    }

    //FUNCION PARA TRAER TODAS LAS CATEGORIAS
    $scope.getCategory = function () {
        $scope.listCategory = [];
        unitOfWork.DiseasesPlague.get(["getCategory"]).then(function (response) {
            $scope.listCategory = response.data.model;
        });
        $scope.diseasesPlagueFarm = {};
    }

    //LISTA DE FINCAS REGISTRADAS
    $scope.getFarms = function () {
        $scope.listFarms = [];
        unitOfWork.Farms.get(["getFarms"]).then(function (response) {
            $scope.listFarms = response.data.model;
        });
    }

    //LISTA DE FINCAS REGISTRADAS
    $scope.getFarmsbyFarms = function (rol, user) {
        $scope.listFarms = [];
        unitOfWork.Farms.get(["getFarmByRol", rol, user]).then(function (response) {
            $scope.listFarms = response.data.model;
        });
    }


    // POST FUNCION PARA GUARDAR NUEVA CATEGORIA
    $scope.postCategory = function () {
        unitOfWork.DiseasesPlague.post(["postCategory"], $scope.Category).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        });
    }

    // FUNCION PARA GUARDAR CAMBIOS DE DATA
    $scope.putCategory  = function () {
        unitOfWork.DiseasesPlague.post(["putCategory"], $scope.Category).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        });
    }
    // FUNCION PARA ELIMINACION CAMPO BASE DE DATOS EN TABLA CATEGORIA
    $scope.deleteCategory  = function (item) {
        Swal.fire({
            title: '¡Aviso!',
            text: '¿Desea eliminar esta categoria? Otros registro pueden resultar afectados',
            type: 'question',
            confirmButtonText: 'Si, Eliminar',
            confirmButtonColor: '#23B931',
            cancelButtonText: 'Cerrar',
            showCancelButton: true,
            cancelButtonColor: '#dc3545'
        }).then((result) => {
            if (result.value) {
                $scope.closeModal()
            } else {
                unitOfWork.DiseasesPlague.get(["getDestroyCategory", item.id]).then(function (response) {
                    if (!response.data.hasError) {
                        Swal.queue([{
                            title: '¡Aviso!',
                            text: response.data.message,
                            confirmButtonText: 'Ok',
                            showLoaderOnConfirm: true,
                            preConfirm: () => {
                                window.location.reload();
                            }
                        }])
                    }
                });
            }
        });

    }

    $scope.other = function (item) {
    
        var opcion = JSON.parse(item);
           console.log(opcion);
        if (opcion.name == "Otro") {
            $scope.otherPlage = true;
        } else {
            $scope.otherPlage = false;
            $scope.diseasesPlagueFarm.othername = null;
        }

    }

    // POST FUNCION PARA GUARDAR NUEVA PLAGA O ENFERMEDAD EN UNA FINCA
    $scope.postDiseasesPlagueFarm = function () {    
        var plage = JSON.parse($scope.diseasesPlagueFarm.id_diseases_plague);
        $scope.item = {};
        $scope.item.id_farm = $scope.diseasesPlagueFarm.id_farm;
        $scope.item.id_diseases_plague = plage.id;
        $scope.item.photo_path = $scope.fileString;
        $scope.item.coordinates = angular.element($('#coordinates')).val();
        $scope.item.othername = $scope.diseasesPlagueFarm.othername;

       // console.log($scope.item);
    
        unitOfWork.DiseasesPlague.post(["postFarmPlagueWeb"], $scope.item).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        });
        
    }


   

    // POST FUNCION PARA GUARDAR NUEVA PLAGA O ENFERMEDAD
    $scope.postDiseasesPlague = function () {

        unitOfWork.DiseasesPlague.post(["postPlagueDiseases"], $scope.diseasesPlague).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        });
    }

    // FUNCION PARA GUARDAR CAMBIOS DE PLAGA O ENFERMEDAD
    $scope.putDiseasesPlague = function () {
        unitOfWork.DiseasesPlague.post(["putPlagueDiseases"], $scope.diseasesPlague).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        });
    }
    // FUNCION PARA ELIMINACION DE PLAGA O ENFERMEDAD
    $scope.deleteDiseasesPlague = function (item) {
        Swal.fire({
            title: '¡Aviso!',
            text: '¿Est seguro de eliminar este registro? ',
            type: 'question',
            confirmButtonText: 'Si, Eliminar',
            confirmButtonColor: '#23B931',
            cancelButtonText: 'Cerrar',
            showCancelButton: true,
            cancelButtonColor: '#dc3545'
        }).then((result) => {
            if (result.value) {
                unitOfWork.DiseasesPlague.get(["getDestroy", item.id]).then(function (response) {
                    if (!response.data.hasError) {
                        Swal.queue([{
                            title: '¡Aviso!',
                            text: response.data.message,
                            confirmButtonText: 'Ok',
                            showLoaderOnConfirm: true,
                            preConfirm: () => {
                                window.location.reload();
                            }
                        }])
                    }
                });
              
            } else {
                $scope.closeModal()
               
            }
        });

    }

    // FUNCION DESPLIEGA MODAL DE NUEVO REGISTRO PARA PLAGAS
    $scope.add = function () {
        $scope.title = "Agregar Nueva Plaga";
        $scope.isUpdate = false;
        $scope.Category = {};
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/diseasesCategory/modal.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        });
    }

    // FUNCION QUE DESPLIEGA MODAL PARA MODIFICAR REGISTRO DE PLAGA
    $scope.editDiseasesPlague = function (item) {
        $scope.title = "Modificar " + item.name;
        $scope.isUpdate = true;
        $scope.diseasesPlague = item;
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/diseasesPlague/modal.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        });
    }

    // FUNCION DESPLIEGA MODAL DE NUEVO REGISTRO PARA CATEGORIA
    $scope.addDiseasesPlague = function () {
        $scope.title = "Agregar Nuevo Registro";
        $scope.isUpdate = false;
        $scope.diseasesPlague = {};
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/diseasesPlague/modal.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        });
    }

    // FUNCION QUE DESPLIEGA MODAL PARA MODIFICAR REGISTRO DE CATEGORIA
    $scope.edit = function (item) {
        $scope.title = "Modificar Registro";
        $scope.isUpdate = true;
        $scope.Category  = item;
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/diseasesCategory/modal.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        });
    }

    // FUNCION PARA CERRAR VENTA MODAL
    $scope.closeModal = function () {
        $rootScope.modalInstance.close();
    };

    function toBase64() {
        if (window.File && window.FileReader && window.FileList && window.Blob) {
            document.getElementById('file').addEventListener('change', handleFileSelect, false);

        } else {
            alert('The File APIs are not fully supported in this browser.');
        }

        function handleFileSelect(evt) {

            var f = evt.target.files[0]; // FileList object
            var reader = new FileReader();
            // Closure to capture the filrmation.
            reader.onload = (function (theFile) {
                return function (e) {
           
                    var binaryData = e.target.result;
                    //Converting Binary Data to base 64
                    var base64String = window.btoa(binaryData);
                    //showing file converted to base64
                    $scope.fileString = base64String;
                };
            })(f);
            // Read in the image file as a data URL.
            reader.readAsBinaryString(f);
        }
    }




    init();
});