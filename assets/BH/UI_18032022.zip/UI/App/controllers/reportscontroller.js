﻿var app = angular.module('app');

app.factory('Excel', function ($window) {
    var uri = 'data:application/vnd.ms-excel;base64,',
        template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>',
        base64 = function (s) { return $window.btoa(unescape(encodeURIComponent(s))); },
        format = function (s, c) { return s.replace(/{(\w+)}/g, function (m, p) { return c[p]; }) };
    return {
        tableToExcel: function (tableId, worksheetName) {
            var table = $(tableId),
                ctx = { worksheet: worksheetName, table: table.html() },
                href = uri + base64(format(template, ctx));
            return href;
        }
    };
}).filter("unique", function () {
    // we will return a function which will take in a collection
    // and a keyname
    return function (collection, keyname) {
        // we define our output and keys array;
        var output = [],
            keys = [];

        // we utilize angular's foreach function
        // this takes in our original collection and an iterator function
        angular.forEach(collection, function (item) {
            // we check to see whether our object exists
            var key = item[keyname];
            // if it's not already part of our keys array
            if (keys.indexOf(key) === -1) {
                // add it to our keys array
                keys.push(key);
                // push this item to our final output array
                output.push(item);
            }
        });
        // return our array which should be devoid of
        // any duplicates
        return output;
    };
}).controller('reportscontroller', function ($scope, $rootScope, $location, authorizationService, unitOfWork, $uibModal, Excel, $timeout) {

    function init() {
        listTechnicalFormData = [];
        $scope.costoInsumosRiego = [];
        recomendaciones = [];
        insumosAgricolasMantenimiento = [];
        situacionCrediticia = [];
        ingresos = [];
        costosLaboresPropiedad = [];
        generalidadesNegocio = [];
        datosGeneralesPropiedad = [];
        informeVisita = [];
        insumosAgricolasPropiedad = [];
        costosLaboresMantenimiento = [];
        concluciones = [];
        costoManoObra = [];

        farmDetailData = [];
        mapDetailData = [];
        cropDetailData = [];
        listusersowner = [];
        farmVisitData = [];

        userAssignId = 0;
        farmAssignId = 0;
        userOwnerAssignName = '';
        userData = [];

        //$scope.getTechnicalFormReport();
        /*dashboard*/
        $scope.labelsMonth = ["Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre", "Enero", "Febrero"];
        $scope.seriesProgram = ['Realizadas', 'No Realizadas'];
        $scope.dataProgram = [
            [65, 59, 80, 81, 56, 55, 40],
            [28, 48, 40, 19, 86, 27, 90]
        ];
        $scope.labelsCumplimiento = ["Programadas", "Realizadas", "No realizadas"];
        $scope.dataCumplimiento = [500, 350, 150];
    /*dashboard*/
        $scope.getusers();
    }

    $scope.exportToExcel = function (tableId) { // ex: '#my-table'
        var exportHref = Excel.tableToExcel(tableId, 'WireWorkbenchDataExport');
        $timeout(function () { location.href = exportHref; }, 100); // trigger download
    };

    $scope.exportToPDF = function (tableId) {
        fullname = 'n';
        html2canvas($(tableId)[0], { useCORS: true }).then((canvas) => {
            var paper_size = [210, 297];
            var img = canvas.toDataURL("image/jpeg");
            var imgWidth = 210;
            var pageHeight = 297;
            var imgHeight = canvas.height * imgWidth / canvas.width;
            var heightLeft = imgHeight;
            var position = 10; // give some top padding to first page
            var pdf = new jsPDF('p', 'mm', "a4");
            pdf.addImage(img, 'jpeg', 0, position, imgWidth, imgHeight, undefined, 'FAST');
            heightLeft -= pageHeight;
            while (heightLeft >= 0) {
                position += heightLeft - imgHeight; // top padding for other pages
                pdf.addPage();
                pdf.addImage(img, 'jpeg', 0, position, imgWidth, imgHeight, undefined, 'FAST');
                heightLeft -= pageHeight;
            }
            pdf.output('save','reporte-perfil-tecnico-cliente-' + fullname + '.pdf');
        });
        return;
    };

    $scope.getUserData = function () {
        unitOfWork.Users.get(["getuser", $scope.userAssignId]).then(function (response) {
            $scope.userData = response.data.model;
        });
        console.log($scope.userData);
    };

    $scope.getusers = function () {
        $scope.listusers = [];
        unitOfWork.Users.get(["getusers"]).then(function (response) {
            $scope.listusers = response.data.model;
        });
    };

    $scope.getUserOwner = function () {
        $scope.listusers = [];
        unitOfWork.Reports.get(["getusersowner"]).then(function (response) {
            $scope.listusersowner = response.data.model;
        });
    };

    $scope.initLineChart = function () {
        $scope.datasetOverride = [{ yAxisID: 'y-axis-1' }, { yAxisID: 'y-axis-2' }];
        $scope.optionsProgram = {
            scales: {
                yAxes: [
                    {
                        id: 'y-axis-1',
                        type: 'linear',
                        display: true,
                        position: 'left'
                    },
                    {
                        id: 'y-axis-2',
                        type: 'linear',
                        display: true,
                        position: 'right'
                    }
                ]
            }
        };
    }

    $scope.setUserId = function (user) {
        $scope.userAssignId = user;
    };

    $scope.setUserOwnerName = function (userOwner) {
        $scope.userOwnerAssignName = userOwner;
    };
    
    $scope.getTechnicalFormReport = function () {

        unitOfWork.Reports.get(["getCostoInsumosRiego", userOwnerAssignName]).then(function (response10) {
            $scope.costoInsumosRiego = response10.data.model;
        });
        unitOfWork.Reports.get(["getRecomendaciones", userOwnerAssignName]).then(function (response12) {
            recomendaciones = response12.data.model;
        });
        unitOfWork.Reports.get(["getInsumosAgricolasMantenimiento", userOwnerAssignName]).then(function (response6) {
            insumosAgricolasMantenimiento = response6.data.model;
        });
        unitOfWork.Reports.get(["getSituacionCrediticia", userOwnerAssignName]).then(function (response2) {
            situacionCrediticia = response2.data.model;
        });
        unitOfWork.Reports.get(["getIngresos", userOwnerAssignName]).then(function (response11) {
            ingresos = response11.data.model;
        });
        unitOfWork.Reports.get(["getCostosLaboresPropiedad", userOwnerAssignName]).then(function (response7) {
            costosLaboresPropiedad = response7.data.model;
        });
        unitOfWork.Reports.get(["getGeneralidadesNegocio", userOwnerAssignName]).then(function (response4) {
            generalidadesNegocio = response4.data.model;
        });
        unitOfWork.Reports.get(["getDatosGeneralesPropiedad", userOwnerAssignName]).then(function (response3) {
            datosGeneralesPropiedad = response3.data.model;
        });
        unitOfWork.Reports.get(["getInformeVisita", userOwnerAssignName]).then(function (response1) {
            informeVisita = response1.data.model;
        });
        unitOfWork.Reports.get(["getInsumosAgricolasPropiedad", userOwnerAssignName]).then(function (response8) {
            insumosAgricolasPropiedad = response8.data.model;
        });
        unitOfWork.Reports.get(["getCostosLaboresMantenimiento", userOwnerAssignName]).then(function (response5) {
            costosLaboresMantenimiento = response5.data.model;
        });
        unitOfWork.Reports.get(["getConclusiones", userOwnerAssignName]).then(function (response13) {
            concluciones = response13.data.model;
        });
        unitOfWork.Reports.get(["getCostoManoObra", userOwnerAssignName]).then(function (response9) {
            costoManoObra = response9.data.model;
        });

        console.log($scope.costoInsumosRiego);
    };


    $scope.getFarmDetailReport = function () {
        $scope.filterParams = {
            user_id: $scope.userAssignId
        };
        unitOfWork.Reports.post(["farmDetailReport"], $scope.filterParams).then(function (response10) {
            console.log(response10);
            $scope.farmDetailData = response10.data.model;
        });
    };

    $scope.getMapDetailReport = function () {
        $scope.filterParams = {
            user_id: $scope.userAssignId
        };
        unitOfWork.Reports.post(["mapDetailReport"], $scope.filterParams).then(function (response11) {
            $scope.mapDetailData = response11.data.model;
        });
    };

    $scope.getCropDetailReport = function () {
        $scope.filterParams = {
            user_id: $scope.userAssignId
        };
        unitOfWork.Reports.post(["cropDetailReport"], $scope.filterParams).then(function (response12) {
            $scope.cropDetailData = response12.data.model;
        });
    };

    $scope.getVisitDetailReport = function () {
    };

    $scope.getVisitTechnicalProfileReport = function () {
        $scope.filterParams = {
            user_id: $scope.userAssignId
        };
        unitOfWork.Reports.post(["getVisitTechnicalProfileReport"], $scope.filterParams).then(function (response) {
            $scope.farmVisitData = response.data.model;
        });
        console.log($scope.farmVisitData);
    };


    init();
});