﻿var app = angular.module('app');

app.controller('farmPlagueController', function ($scope, $rootScope, $location, authorizationService, unitOfWork, $uibModal, leafletData){

    function init() {

        $scope.isVisible = false;
        var info = {};
        info.photo_path = "https://visioncanaria.com.uy/media/images/empty.jpg";
        $scope.infoPlage = info;

        $scope.blue = {
            lat: 13.8333000,
            lng: -88.9167000,
            zoom: 7
        }
        $scope.loadMap();
        $scope.UserData = $scope.user.user; 
        //FILTRO DE PLAGAS Y ENFERMEDADES POR ROL
        if ($scope.UserData.id_rol == 6 || $scope.UserData.id_rol == 5) {      
            $scope.getMyFarmsPlage($scope.UserData.id_rol, $scope.UserData.id);
        } else {
            if ($scope.UserData.id_rol != 6 || $scope.UserData.id_rol != 5) {
                $scope.getFarmsPlage(0);
            }
        }    
    }

    $scope.allplage = function () {
        $scope.dataList = [];
        unitOfWork.DiseasesPlague.get(["getDeseasePlaguefarmAll", 0]).then(function (response) {
            $scope.listData2 = response.data.model;
            console.log(response.data.model);
            angular.forEach($scope.listData2, function (value, key) {
    
                try {

                    $scope.dataPlage = {}
                    var val = JSON.parse(value.coordinates);
                    var plage = {};
                    plage.Name = value.plage;
                  
                    plage.category = value.category;
                    $scope.dataPlage.type = "Feature";
                    $scope.dataPlage.properties = plage;
                    $scope.dataPlage.geometry = val.geometry;
                    $scope.dataList.push($scope.dataPlage);
            
                } catch (error) {

                }          
            }) 
            localStorage.setItem("plagesList", JSON.stringify($scope.dataList));
            console.log(localStorage.getItem("plagesList"));
            
            var url = window.location.protocol + "//" +
                window.location.host +
                (window.location.host.indexOf(":") != -1 ? "" : (window.location.port ? ":" + window.location.port : "")) +
                window.location.pathname;
            url = url.toUpperCase().split("ACCOUNT")[0].toLocaleLowerCase();
            url = url + 'Plage/';
            window.location.href = url;
        });

    }


    $scope.loadMap = function () {
        angular.extend($scope, {
            berlin: $scope.blue,
            controls: {
                draw: {}
                   
            },
            markers: $scope.marks,
            defaultIcon: {},
            layers: {
                baselayers: {
                    osm: {
                        name: 'Google-Hybrid',
                        url: "https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}",
                        type: 'xyz'                    
                    },
                    googleTerrain: {
                        name: 'Google-Map',
                        url: 'https://mt1.google.com/vt/lyrs=r&x={x}&y={y}&z={z}',
                        type: 'xyz'
                    },
                    googleHybrid: {
                        name: 'Google-Satellite',
                        url: 'https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}',
                        type: 'xyz' 
                       
                    }

                },
                overlays: {
                    draw: {
                        name: 'draw',
                        type: 'group',
                        visible: true,
                        layerParams: {
                            showOnSelector: false
                        }
                    }

                }
            }

        });

        leafletData.getMap().then(function (map) {
            leafletData.getLayers().then(function (baselayers) {
                var drawnItems = baselayers.overlays.draw;
                map.on('draw:created', function (e) {
                    var layer = e.layer;
                    drawnItems.addLayer(layer);
                   // console.log(JSON.stringify(layer.toGeoJSON()));
                });
            });
        });

    }

    //FUNCION PARA RECARGAR PAGINA
    $scope.reflesh = function () {
        window.location.reload();
    }

    //LISTA DE PLAGAS Y ENFERMEDADES DE UNA FINCA 
    $scope.getFarmsPlage = function (id) {
        $scope.listData = [];
        unitOfWork.DiseasesPlague.get(["getDeseasePlaguefarmAll", id]).then(function (response) {
            $scope.listData = response.data.model;
        });
    }


    //LISTA DE PLAGAS Y ENFERMEDADES DE UNA FINCA 
    $scope.getFarmsPlage2 = function (id) {
        $scope.listData2 = [];
        unitOfWork.DiseasesPlague.get(["getDeseasePlaguefarmAll",id]).then(function (response) {
            $scope.listData2 = response.data.model;
        });
    }

    //LISTA DE PLAGAS Y ENFERMEDADES DE UNA FINCA 
    $scope.getMyFarmsPlage = function (rol,user) {
        $scope.listData = [];
        unitOfWork.DiseasesPlague.get(["getDeseasePlagueMyfarmAll",rol,user]).then(function (response) {
            $scope.listData = response.data.model;
        });
    }

     //MODAL PARA BORRAR FINCA
    $scope.deleteFarm = function (item) {
        Swal.fire({
            title: '¡Aviso!',
            text: 'Desea eliminar esta finca',
            type: 'question',
            confirmButtonText: 'Si, Eliminar',
            confirmButtonColor: '#23B931',
            cancelButtonText: 'Cerrar',
            showCancelButton: true,
            cancelButtonColor: '#dc3545'
        }).then((result) => {
            if (result.value) {
                unitOfWork.Farms.get(["deleteFarms", item.id]).then(function (response) {
                    if (!response.data.hasError) {
                        Swal.queue([{
                            title: '¡Aviso!',
                            text: response.data.message,
                            confirmButtonText: 'Ok',
                            showLoaderOnConfirm: true,
                            preConfirm: () => {
                                window.location.reload();
                            }
                        }])
                    }
                });
            } else {
                $scope.closeModal()
               
            }
        });
    }

    // FUNCION PARA REPORTAR UNA PLAGA CONTROLADA 
    $scope.check = function (item) {
        $scope.data = item;
        Swal.fire({
            title: '¡Aviso!',
            text: 'Desea reportar que la ' + item.category + ' ' + item.plage+' se ha solucionado en '+item.farm,
            type: 'question',
            confirmButtonText: 'Si, Estoy seguro',
            confirmButtonColor: '#23B931',
            cancelButtonText: 'Cerrar',
            showCancelButton: true,
            cancelButtonColor: '#dc3545'
        }).then((result) => {
            if (result.value) {
                unitOfWork.DiseasesPlague.post(["putCheck"], $scope.data).then(function (response) {
                    if (!response.data.hasError) {
                        Swal.queue([{
                            title: '¡Aviso!',
                            text: response.data.message,
                            confirmButtonText: 'Ok',
                            showLoaderOnConfirm: true,
                            preConfirm: () => {
                                window.location.reload();
                            }
                        }])
                    }
                });
            } else {
                $scope.closeModal()
               
            }
        });
    }

    //INFORMACION DE PLAGA Y COORDENADAS
    $scope.info = function (item) {
        $scope.isVisible = true;
        $scope.marks = [];
        $scope.infoPlage = item;
        //console.log(item);
        $scope.coordinate = JSON.parse(item.coordinates);
        var coordinate = {}
        coordinate.lat = $scope.coordinate.geometry.coordinates[1];
        coordinate.lng = $scope.coordinate.geometry.coordinates[0];
        coordinate.icon = {
            iconUrl: "https://img.icons8.com/ultraviolet/50/000000/marker.png"
        };
        $scope.blue = {
            lat: $scope.coordinate.geometry.coordinates[1],
            lng: $scope.coordinate.geometry.coordinates[0],
            message: item.plage,
            zoom: 18
        }
        $scope.marks.push(coordinate);
        $scope.loadMap();
    }

    
    $scope.view = function (item) {
        $scope.item = item;
        if (item.plage == 'Otro') {
            $scope.title = item.category + " - " + item.othername;
        } else {
            $scope.title = item.category + " - " + item.plage;
        }     
        $scope.isUpdate = true;
        $rootScope.modalInstance = $uibModal.open({
        templateUrl: 'app/views/diaseasePlagueFarm/Details.html',
        size: 'lg',
        windowClass: 'custom-modal',
        scope: $scope,
        animation: false
        });
    }
        //FUNCION PARA CERRAR MODAL
    $scope.closeModal = function () {
        $rootScope.modalInstance.close();
    };


    function toBase64() {
        if (window.File && window.FileReader && window.FileList && window.Blob) {
            document.getElementById('file').addEventListener('change', handleFileSelect, false);

        } else {
            alert('Este archivo no es soportado');
        }

        function handleFileSelect(evt) {

            var f = evt.target.files[0]; // FileList object
            var reader = new FileReader();
            // Captura la informacion
            reader.onload = (function (theFile) {
                return function (e) {
                    var binaryData = e.target.result;
         
                    var base64String = window.btoa(binaryData);
                    //Se guarda el archivo base64 en una variable
                    $scope.fileString = base64String;
                };
            })(f);
            // 
            reader.readAsBinaryString(f);
        }
    }

 


    init();



});