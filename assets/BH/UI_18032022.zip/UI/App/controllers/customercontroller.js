﻿var app = angular.module('app');

app.controller('customercontroller', function ($scope, $rootScope, $location, authorizationService, unitOfWork, $uibModal) {

    function init() {
        $scope.getusers();
        $scope.getRoles();
        $scope.getCountry();
        $scope.KML = [];
        $scope.map = false;
        $scope.data = {};
        setTimeout(function () { toBase64(); }, 5000);
    
 
        if (localStorage.getItem("Cus") != null) {
            $scope.customer = JSON.parse(localStorage.getItem("Cus"));
            $scope.getFarmsbyFarms($scope.customer.id_rol, $scope.customer.id);
        }
    }


    //LISTA DE FINCAS REGISTRADAS
    $scope.getFarmsbyFarms = function (rol, user) {
        $scope.listFarmsCus = [];
        unitOfWork.Farms.get(["getFarmByRol", rol, user]).then(function (response) {
            $scope.listFarmsCus = response.data.model;
        });
    }


    $scope.reflesh = function () {
        window.location.reload();
    }

    //LISTA DE DEPARTAMENTOS
    $scope.getCountry = function () {
        $scope.listCountry = [];
        unitOfWork.Country.get(["getCountry"]).then(function (response) {
            $scope.listCountry = response.data.model;
        });
    }
    //FUNCIONA PARA TRAER TODOS LOS USUARIOS 
    $scope.getusers = function () {
        $scope.listusers = [];
        unitOfWork.Users.get(["getusers"]).then(function (response) {
            $scope.listusers = response.data.model;
        });
    }
    //FUNCION PARA GUARDAR DATOS DE NUEVO USUARIO
    $scope.newCustomer = function () {
        $scope.data.coordinate = angular.element($('#coordinates')).val();
        $scope.data.kml_file_path = $scope.fileString;
        $scope.data.map_kml = $scope.KmlFileString;
        console.log($scope.data);
        unitOfWork.Farms.post(["postFarm"],$scope.data).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
           
        });
    }
    // FUNCION PARA ACTUALIZAR INFORMACION  DE USUARIO
    $scope.putusers = function () {

        $scope.aux = $scope.user;
        if (typeof ($scope.pass.passwordOther) != 'undefined') {
            $scope.user.password = $scope.pass.passwordOther;
        }

        if (typeof ($scope.pass.passwordOther) == 'undefined') {
            $scope.user.password = $scope.aux.password;
        } 

        unitOfWork.Users.post(["putUser"], $scope.aux).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        });
    }
    // FUNCION PARA ELIMINA DATOS DE USUARIO
    $scope.deleteusers = function (item) {
        Swal.fire({
            title: '¡Aviso!',
            text: 'Desea eliminar este Usuario',
            type: 'question',
            confirmButtonText: 'Si, Eliminar',
            confirmButtonColor: '#23B931',
            cancelButtonText: 'Cerrar',
            showCancelButton: true,
            cancelButtonColor: '#dc3545'
        }).then((result) => {
            if (result.value) {
                unitOfWork.Users.get(["getDestroy", item.id]).then(function (response) {
                    if (!response.data.hasError) {
                        Swal.queue([{
                            title: '¡Aviso!',
                            text: response.data.message,
                            confirmButtonText: 'Ok',
                            showLoaderOnConfirm: true,
                            preConfirm: () => {
                                window.location.reload();
                            }
                        }])
                    }
                });
        
            } else {
                $scope.closeModal()
                
            }
        });
    }
    // FUNCION QUE DESPLIEGA MODAL PARA NUEVO USUARIO
    $scope.addusers = function () {
        $scope.title = "Agregar Usuario";
        $scope.isUpdate = false;
        $scope.user = {};;
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/users/modal.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        })
    }
    // FUNCION QUE DESPLIEGA MODAL PARA MODIFICACION DE INFORMACION DE USUARIO
    $scope.modusers = function (item) {
        $scope.title = "Modificar información de " + item.Name;
        $scope.isUpdate = true;
        $scope.pass = {};
        $scope.user = item;
   
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/users/modal.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        });
    }
    //FUNCION PARA LISTAR TODOS LOS ROLES DISPONIBLES
    $scope.getRoles = function () {
        $scope.listRoles = [];
        unitOfWork.Roles.get(["getRoles"]).then(function (response) {
            $scope.listRoles = response.data.model;
        });
    }

    //FUNCION PARA CERRAR MODAL
    $scope.closeModal = function () {
        $rootScope.modalInstance.close();
    };

    $scope.showInf = function (item) {
        localStorage.setItem("Cus", JSON.stringify(item));
        window.location.href = "#!/CustomerInformation";

    }


    $scope.SelectFile = function (file) {
        $scope.SelectedFile = file;
        console.log($scope.SelectFile);
      
    };


    function toBase64() {
        if (window.File && window.FileReader && window.FileList && window.Blob) {
            document.getElementById('file').addEventListener('change', handleFileSelect, false);
            if (!!document.getElementById('map_file')) {
                document.getElementById('map_file').addEventListener('change', handleFileSelect, false);
            }
        } else {
            alert('The File APIs are not fully supported in this browser.');
        }

        function handleFileSelect(evt) {

            var f = evt.target.files[0]; // FileList object
            var flag = evt.target.id;
            var reader = new FileReader();
            // Closure to capture the file information.
            reader.onload = (function (theFile) {
                return function (e) {
                    var binaryData = e.target.result;
             
                    //Converting Binary Data to base 64
                    var base64String = window.btoa(binaryData);
                    //showing file converted to base64
                    if (flag == "file") {
                        $scope.fileString = base64String;
                    } else {
                        $scope.KmlFileString = base64String;
                    }
                };
            })(f);
            // Read in the image file as a data URL.
            reader.readAsBinaryString(f);
        }
    }

    init();
});