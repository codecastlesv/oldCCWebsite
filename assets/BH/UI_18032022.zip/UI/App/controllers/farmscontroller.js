﻿var app = angular.module('app');

app.controller('farmscontroller', function ($scope, $rootScope, $location, authorizationService, unitOfWork, $uibModal) {

    function init() {
        $scope.getusers();
        $scope.getCountry();
        $scope.userData = $scope.user.user;
        $scope.farm = {};

        //CARGAR FINCAS SEGUN ROL Y USUARIO
        if ($scope.userData.id_rol == 6 || $scope.userData.id_rol == 5) {
            $scope.getFarmsbyFarms($scope.userData.id_rol, $scope.userData.id);
        } else {
            $scope.getFarms();
        }
        setTimeout(function () { toBase64(); }, 5000);

    }
    //FUNCION PARA REFLESCAR PAGINA
    $scope.reflesh = function () {
        window.location.reload();
    }

    //LISTA DE FINCAS REGISTRADAS
    $scope.getFarms = function () {
        $scope.listFarms = [];
        unitOfWork.Farms.get(["getFarms"]).then(function (response) {
            $scope.listFarms = response.data.model;
           // console.log($scope.listFarms);
        });  
    }

    //LISTA DE FINCAS REGISTRADAS
    $scope.getFarmsbyFarms = function (rol, user) {
        $scope.listFarms = [];
        unitOfWork.Farms.get(["getFarmByRol", rol, user]).then(function (response) {
            $scope.listFarms = response.data.model;
            //console.log($scope.listFarms);
        });
    }

    //LISTA DE DEPARTAMENTOS
    $scope.getCountry = function () {
        $scope.listCountry = [];
        unitOfWork.Country.get(["getCountry"]).then(function (response) {
            $scope.listCountry = response.data.model;
        });
    }

    //LISTA DE USUARIOS PARA MOSTRAR LOS TITULADORES DE CADA PROPIEDAD
    $scope.getusers = function () {
        $scope.listusers = [];
        unitOfWork.Users.get(["getUsers"]).then(function (response) {
            $scope.listusers = response.data.model;
        });
    }

    //FUNCION PARA GUARDA DATOS DE NUEVA FINCA 
    $scope.postFarm = function () {
        unitOfWork.Farms.post(["postFarm"], $scope.farm).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        });
    }

    //FUNCION QUE MODIFICIA DATOS DE NUEVA FINCA
    $scope.putFarm = function () {
        $scope.farm.kml_file_path = $scope.fileString;
        //$scope.farm.map_file = $scope.KmlFileString;
        $scope.farm.map_kml = $scope.KmlFileString
        $scope.farm.coordinates = angular.element($('#coordinates')).val();
        unitOfWork.Farms.post(["putFarm"], $scope.farm).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        });
    };

    //FUNCION QUE ELIMINA DATOS DE FINCA 
    $scope.deleteFarm = function (item) {
      
        Swal.fire({
            title: '¡Aviso!',
            text: 'Desea eliminar esta finca',
            type: 'question',
            confirmButtonText: 'Si, Eliminar',
            confirmButtonColor: '#23B931',
            cancelButtonText: 'Cerrar',
            showCancelButton: true,
            cancelButtonColor: '#dc3545'
        }).then((result) => {
            if (result.value) {
                unitOfWork.Farms.get(["getDestroy", item.id]).then(function (response) {
                    if (!response.data.hasError) {
                        Swal.queue([{
                            title: '¡Aviso!',
                            text: response.data.message,
                            confirmButtonText: 'Ok',
                            showLoaderOnConfirm: true,
                            preConfirm: () => {
                                window.location.reload();
                            }
                        }])
                    }
                });
               
            } else {
                $scope.closeModal()
            }
        });
    }

    //MODAL PARA EDITAR DATOS DE FINCA 
    $scope.modFarm = function (item) {
        console.log(item);
        $scope.farm = item;
        $scope.title = "Modificar Información de " + item.name;
        $scope.isUpdate = true;
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/farms/modal.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        });

        setTimeout(function () { toBase64()}, 3000);
    }

    //LISTA DE ROLES 
    $scope.getRoles = function () {
        $scope.listRoles = [];
        unitOfWork.Roles.get(["getRoles"]).then(function (response) {
            $scope.listRoles = response.data.model;
        });
    }

    //UBICACION DINAMICA DE MAPA POR DEPARTAMENTO  <-------------PENDIENTE DE VER SI PODEMOS DESPLEGAR TODAS LAS HERRAMIENTAS CON ANGULARJS
    $scope.coordinatesCountry= function (state) {  
        var country = JSON.parse(state);
        $scope.id_country = country.id;
        var points = JSON.parse(country.coordinate);
       // console.log(points.geometry.coordinates)
    }


    //CAPTURA ID DE FINCA Y REDIRECCIONA A DASHBOARD DE DETALLES
    $scope.details = function (item) {

        try {
            var data = JSON.parse(item.coordinates);
            if (item.coordinates != null) {
                $scope.farmCoordinates = '';
                try {
                    var data = JSON.parse(item.coordinates);
                    $scope.coordinates = {
                        lat: data.geometry.coordinates[0][0][0],
                        lng: data.geometry.coordinates[0][0][1],
                        zoom: 14
                    }
                    localStorage.setItem("Coordinates", JSON.stringify($scope.coordinates));
                } catch (error) {
                    $scope.coordinates = {
                        lat: - 88.9167000,
                        lng: 13.8333000,
                        zoom: 7
                    }
                    localStorage.setItem("Coordinates", JSON.stringify($scope.coordinates));
                }
            }
        } catch (error) {
            $scope.coordinates = {
                lat: - 88.9167000,
                lng: 13.8333000,
                zoom: 7
            }
            localStorage.setItem("Coordinates", JSON.stringify($scope.coordinates));

        } finally {
            localStorage.setItem("farm", item.id);
            localStorage.setItem("farmitem", JSON.stringify(item));
            window.location.href = "#!/Details";
        }
       
    
    }

 
    //CIERRA VENTA MODAL
    $scope.closeModal = function () {
        $rootScope.modalInstance.close();
    };

    //CONVIERTE ARCHIVO A SUBIR A SERVIDOR A BASE 64
    function toBase64() {
        if (window.File && window.FileReader && window.FileList && window.Blob) {
            console.log(document.getElementById('file'));
            document.getElementById('file').addEventListener('change', handleFileSelect, false);
            if (document.getElementById('map_file')) {
                console.log(document.getElementById('map_file'));
                document.getElementById('map_file').addEventListener('change', handleFileSelect, false);
            }
        } else {
            alert('The File APIs are not fully supported in this browser.');
        }

        function handleFileSelect(evt) {

            var f = evt.target.files[0]; // FileList object
            var flag = evt.target.id;
            var reader = new FileReader();
            reader.onload = (function (theFile) {
                return function (e) {
                    var binaryData = e.target.result;
                    //Converting Binary Data to base 64
                    var base64String = window.btoa(binaryData);
                    //showing file converted to base64
                    if (flag == "file") {
                        $scope.fileString = base64String;
                    } else {
                        $scope.KmlFileString = base64String;
                    }
                };
            })(f);
            // Read in the image file as a data URL.
            reader.readAsBinaryString(f);
        }
    }

    //PUBLICAR UNA FINCA DE USUARIO YA REGISTRADO.
    $scope.postNewFarm = function () {
        $scope.farm.id_country = $scope.id_country;
        $scope.farm.kml_file_path = $scope.fileString;
        $scope.farm.map_kml = $scope.KmlFileString;
        $scope.farm.coordinates = angular.element($('#coordinates')).val();

        //CARGAR FINCAS SEGUN ROL Y USUARIO
        if ($scope.userData.id_rol == 6 || $scope.userData.id_rol == 5) {
            $scope.farm.id_owner = $scope.userData.id;    
        } 
        
   
        unitOfWork.Farms.post(["postFarmExistUserWeb"], $scope.farm).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        });
    }


    $scope.download = function (file) {
        try {
            if (file.coordinates.includes("}")) {
                console.log(typeof file.coordinates);
                var json = JSON.parse(file.coordinates);
                console.log(json);
                var kml = tokml(json);
                console.log(kml);
                if (kml) {
                    var Now = new Date();
                    var date = Now.getDate() + "-" + Now.getMonth() + "-" + Now.getFullYear();
                    var Name = file.name + "_" + date;
                    var FileName = Name.trim() + ".kml"

                    download(kml, FileName, "application/vnd.google-earth.kml+xml");
                    }
            } else if (file.map_file.length > 2) {
                var aElement = document.createElement("a");
                aElement.href = file.map_file;
                var Now = new Date();
                var date = Now.getDate() + "-" + Now.getMonth() + "-" + Now.getFullYear();
                var Name = file.name + "_" + date;
                var FileName = Name.trim() + ".kml"
                aElement.setAttribute("download", FileName);
                aElement.click();
                aElement.remove();
            }
        } catch (error) {
            Swal.queue([{
                title: '¡Lo sentimos!',
                text: "No se puedo generar el archivo,Esta finca posee coordenadas invalidas!",
                confirmButtonText: 'Ok',
                showLoaderOnConfirm: true,
                preConfirm: () => {
                   
                }
            }])
        }
    }
    init();
});