﻿angular.module('app');

app.controller('mapsController', function ($scope, $rootScope, $location, authorizationService, unitOfWork, $uibModal) {

    function init() {

        $scope.getMaps();
        $scope.state = false;
        $scope.save = true;
        $scope.getFarms();
        $scope.map = {};
        $scope.getFarms();
        $scope.getMapsFarm();
        $scope.table1 = true;
        $scope.table2 = false;
        $scope.isVisible = false;
        $scope.getAllMaps(0);
        setTimeout(function () { toBase64(); }, 5000);

    }

    $scope.getFarms = function () {
        $scope.listFarms = [];
        user = JSON.parse(localStorage.getItem("user")).user

        if(user.id_rol == 1){
            unitOfWork.Farms.get(["getFarms"]).then(function (response) {
                $scope.listFarms = response.data.model;
            });
        }else{
            unitOfWork.Farms.get(["getMapsByUser", user.id]).then(function (response) {
                $scope.listFarms = response.data.model;
            });    
        }

        
    }


    $scope.reflesh = function () {
        window.location.reload();
    }


    $scope.getAllMaps = function (type) {
        var selectType = 1;
        $scope.MapsLinks = [];
        unitOfWork.Maps.get(["getMapCategory", selectType]).then(function (response) {
            $scope.MapsLinks = response.data.model;
            if ($scope.MapsLinks.length > 1) {
                $scope.tableMap = true;
            }
         
        });
        if ($scope.MapsLinks.length > 1) {
            $scope.tableMap = true;
        }
    }

    $scope.viewAllMapsFarm= function(){
       
        localStorage.setItem("AllMapsFarm", JSON.stringify($scope.MapsLinks));

        var url = window.location.protocol + "//" +
            window.location.host +
            (window.location.host.indexOf(":") != -1 ? "" : (window.location.port ? ":" + window.location.port : "")) +
            window.location.pathname;
        url = url.toUpperCase().split("ACCOUNT")[0].toLocaleLowerCase();
        url = url + 'Maps/AllMapsFarm.html';
        window.location.href = url; 
    }

    $scope.viewAll = function (data) {
        $scope.mapsAll = [];
        $scope.farmCoordinates = '';
        try {
            angular.forEach(data, function (key, value) {
                $scope.mapsAll.push((key.file_path));
                $scope.farmCoordinates = key.coordinates;
            });

            $scope.coordinates = {
                lat: data.geometry.coordinates[0][0][0],
                lng: data.geometry.coordinates[0][0][1],
                zoom: 18
            }
    
            localStorage.setItem("Coordinates", JSON.stringify($scope.coordinates));
        } catch (error) {
            $scope.coordinates = {
                lat: - 88.9167000,
                lng: 13.8333000,
                zoom: 9
            }
            localStorage.setItem("Coordinates", JSON.stringify($scope.coordinates));
        }

        localStorage.setItem("MapsAll", $scope.mapsAll);

  
        var url = window.location.protocol + "//" +
            window.location.host +
            (window.location.host.indexOf(":") != -1 ? "" : (window.location.port ? ":" + window.location.port : "")) +
            window.location.pathname;
        url = url.toUpperCase().split("ACCOUNT")[0].toLocaleLowerCase();
        url = url + 'Maps/AllMap.html';
        window.location.href = url; 
        
    }


    $scope.Select = function (item) {
        //console.log(item);
        var id = item;
        $scope.listMapsFarm = [];
      
        if (item != 0) {
      
            $scope.table1 = false;
            $scope.table2 = true;
            var number;



            unitOfWork.Maps.get(["getMap", item]).then(function (response) {
                $scope.listMapsFarm = response.data.model;
                console.log($scope.listMapsFarm);
                number = $scope.listMapsFarm.length;
                if ($scope.listMapsFarm.length > 1) {
                    $scope.isVisible = true;
                } else {
                    $scope.isVisible = false;
                }
            });
            
        }

        if (item == 0) {

            $scope.table1 = true;
            $scope.table2 = false;

            userId = 0;
            user = JSON.parse(localStorage.getItem("user")).user;
            modelData = [];
            if (user.id_rol !== 1) {
                userId = user.id;
                console.log(userId);
                unitOfWork.Farms.get(["getFarmByOwner", userId]).then(function (response) {
                    angular.forEach(response.data.model, function (key, value) {
                        console.log(key);
                        newModel = {
                            id: key.id,
                            coordinates: key.coordinates,
                            date_map: moment().format('d MMMM YYYY'),
                            description: '',
                            farm: key.name,
                            file_path: key.map_file,
                            id_farm: key.id,
                            name: 'Mapa de Areas',
                            status: 0
                        };
                        modelData.push(newModel);
                    });
                    $scope.listMapsFarm = modelData;
                });
            } else {
                unitOfWork.Farms.get(["getFarms"]).then(function (response) {
                    angular.forEach(response.data.model, function (key, value) {
                        console.log(key);
                        newModel = {
                            id: key.id,
                            coordinates: key.coordinates,
                            date_map: moment().format('d MMMM YYYY'),
                            description: '',
                            farm: key.name,
                            file_path: key.map_file,
                            id_farm: key.id,
                            name: 'Mapa de Areas',
                            status: 0
                        };
                        modelData.push(newModel);
                    });
                    $scope.listMapsFarm = modelData;
                });
            }

          
        }
    }
  
    //LISTA DE FINCAS REGISTRADAS
    $scope.getFarms = function () {
        $scope.listFarms = [];
        userId = 0;
        user = JSON.parse(localStorage.getItem("user")).user;

        if (user.id_rol !== 1) {
            userId = user.id;
            console.log(userId);
            unitOfWork.Farms.get(["getFarmByOwner", userId]).then(function (response) {
                $scope.listFarms = response.data.model;
            });
        } else {
            unitOfWork.Farms.get(["getFarms"]).then(function (response) {
                $scope.listFarms = response.data.model;
            });
        }
        
    }

    $scope.getMapsFarm = function () {
        $scope.listMFarm = [];
        unitOfWork.Maps.get(["getMaps"]).then(function (response) {
            $scope.listMFarm = response.data.model;
        });
    }

    //LISTA DE TIPOS DE MAPAS
    $scope.getMaps = function () {
        $scope.listMaps = [];
        unitOfWork.Maps.get(["getMapCategory"]).then(function (response) {
            $scope.listMaps = response.data.model;
        });
    }
    // METODO POST MAPA
    $scope.postMaps = function () {
        unitOfWork.Maps.post(["postMapCategory"], $scope.map).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        });
        init();
    }

    //METODO UPDATE 
    $scope.putMaps = function () {
        unitOfWork.Maps.post(["putMapCategory"], $scope.map).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        });
    }

    //METODO DELETE
    $scope.deleteMaps = function (item) { 
        Swal.fire({
            title: '¡Aviso!',
            text: 'Desea eliminar este registro?',
            type: 'question',
            confirmButtonText: 'Si, Eliminar',
            confirmButtonColor: '#23B931',
            cancelButtonText: 'Cerrar',
            showCancelButton: true,
            cancelButtonColor: '#dc3545'
        }).then((result) => {
            if (result.value) {
                unitOfWork.Maps.get(["getDestroyCategory", item.id]).then(function (response) {
                    if (!response.data.hasError) {
                        Swal.queue([{
                            title: '¡Aviso!',
                            text: response.data.message,
                            confirmButtonText: 'Ok',
                            showLoaderOnConfirm: true,
                            preConfirm: () => {
                                window.location.reload();
                            }
                        }])

                    }
                });

               
            } else {
                $scope.closeModal()
               
            }
        });
    }

    //MODAL PARA NUEVO MAPA
    $scope.addMaps = function () {
        $scope.title = "Nuevo Registro";
        $scope.isUpdate = false;
        $scope.map = {};
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/map/modal.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        });
    }
    //MODAL PARA MODIFICAR MAPA
    $scope.modMaps = function (item) {
        $scope.map = item;
        $scope.title = "Modificar Registro";
        $scope.isUpdate = true;
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/map/modal.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        });
    }

    /************************************************************************************************************************************* */
/*FUNCIONES PARA DAR DE ALTA MAPAS DE UNA FINCA */


    $scope.postMapFarm = function () {
        $scope.map.file_path = $scope.fileString;
        console.log($scope.map);
        $scope.map.map_name = $(".map-select option:selected").text().split(' ').join('_');
        $scope.map.id_crop = null;  
        $scope.map.date_map = moment(angular.element('#start').val()).format('YYYY-MM-DD');
       // console.log($scope.map);
        
        unitOfWork.Maps.post(["postMap"], $scope.map).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        }); init();
     
    }

    $scope.UpdateMapFarm = function () {
        if (typeof ($scope.fileString) == 'undefined') {
            $scope.map.opc = 0;
        } 

        if (typeof ($scope.fileString) != 'undefined') {
            $scope.map.opc = 1;
            $scope.map.file_path = $scope.fileString;
        }
        $scope.map.map_name = $(".map-select option:selected").text().split(' ').join('_');
        $scope.map.id_crop = null;  
        unitOfWork.Maps.post(["putMap"], $scope.map).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        });
        init();
    }

    $scope.deleteMapFarm = function (item) {
        Swal.fire({
            title: '¡Aviso!',
            text: 'Desea eliminar este registro?',
            type: 'question',
            confirmButtonText: 'Si, Eliminar',
            confirmButtonColor: '#23B931',
            cancelButtonText: 'Cerrar',
            showCancelButton: true,
            cancelButtonColor: '#dc3545'
        }).then((result) => {
            if (result.value) {
                unitOfWork.Maps.get(["getDestroy", item.id]).then(function (response) {
                    if (!response.data.hasError) {
                        Swal.queue([{
                            title: '¡Aviso!',
                            text: response.data.message,
                            confirmButtonText: 'Ok',
                            showLoaderOnConfirm: true,
                            preConfirm: () => {
                                window.location.reload();
                            }
                        }])

                    }
                });
            } else {
                $scope.closeModal()
               

            }
        });
    }


    //MODAL PARA MODIFICAR MAPA
    $scope.modMapFarm = function (item) {
        $scope.map = item;
        $scope.title = "Modificar Registro";
        $scope.isUpdate = true;
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/map/MapFarmModal.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        });
    }


    function toBase64() {
        if (window.File && window.FileReader && window.FileList && window.Blob) {
            document.getElementById('file').addEventListener('change', handleFileSelect, false);


        } else {
            alert('The File APIs are not fully supported in this browser.');
        }

        function handleFileSelect(evt) {

            var f = evt.target.files[0]; // FileList object
            var reader = new FileReader();
            // Closure to capture the filrmation.
            reader.onload = (function (theFile) {
                return function (e) {

                    var binaryData = e.target.result;
                    //Converting Binary Data to base 64
                    var base64String = window.btoa(binaryData);
                    //showing file converted to base64

                    $scope.fileString = base64String;
               
                
                };
            })(f);
            // Read in the image file as a data URL.
            reader.readAsBinaryString(f);
    
        }
    }



    $scope.ViewMap = function (item) {
        if (item.coordinates != null) {
            $scope.farmCoordinates = '';
            try {
                var data = JSON.parse(item.coordinates);
                $scope.coordinates = {
                    lat: data.geometry.coordinates[0][0][0],
                    lng: data.geometry.coordinates[0][0][1],
                    zoom: 17
                }
               
                localStorage.setItem("Coordinates", JSON.stringify($scope.coordinates));  

            } catch (error) {
                $scope.coordinates = {
                    lat:  - 88.9167000,
                    lng: 13.8333000,
                    zoom: 9
                }
                console.log($scope.coordinates);
                localStorage.setItem("Coordinates", JSON.stringify($scope.coordinates));  
            }
        }
       
        localStorage.setItem("Maps", JSON.stringify(item));   
        var url = window.location.protocol + "//" +
            window.location.host +
            (window.location.host.indexOf(":") != -1 ? "" : (window.location.port ? ":" + window.location.port : "")) +
            window.location.pathname;
        url = url.toUpperCase().split("ACCOUNT")[0].toLocaleLowerCase();
        url = url + 'Maps/';
        window.location.href = url;
        console.log(item);
    }


    //FUNCION PARA CERRAR MODAL
    $scope.closeModal = function () {
        $rootScope.modalInstance.close();
    };

  

    init();
});