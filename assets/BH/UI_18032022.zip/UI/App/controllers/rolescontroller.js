﻿var app = angular.module('app');

app.controller('rolesController', function ($scope, $rootScope, $location, authorizationService, unitOfWork, $uibModal) {

    function init() {
        $scope.getRoles();
    }

    $scope.reflesh = function () {
        window.location.reload();
    }

    //FUNCION PARA TRAER TODOS LOS ROLES 
    $scope.getRoles = function () {
        $scope.listRoles = [];
        unitOfWork.Roles.get(["getRoles"]).then(function (response) {
            $scope.listRoles = response.data.model;
        });
    }

    // POST FUNCION PARA GUARDAR UN ROL NUEVO
    $scope.postRoles = function () {
        unitOfWork.Roles.post(["postRol"], $scope.rol).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        });
    }

     // FUNCION PARA GUARDAR CAMBIOS DE DATA
    $scope.putRoles = function () {
        console.log($scope.rol);
        unitOfWork.Roles.post(["putRol"], $scope.rol).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        });
    }
    // FUNCION PARA ELIMINACION CAMPO BASE DE DATOS 
    $scope.deleteRol = function (item) {
        console.log(item);
        Swal.fire({
            title: '¡Aviso!',
            text: 'Desea eliminar este archivo',
            type: 'question',
            confirmButtonText: 'Si, Eliminar',
            confirmButtonColor: '#23B931',
            cancelButtonText: 'Cerrar',
            showCancelButton: true,
            cancelButtonColor: '#dc3545'
        }).then((result) => {
            if (result.value) {
                unitOfWork.Roles.get(["deleteRol", item.id]).then(function (response) {
                    if (!response.data.hasError) {
                        Swal.queue([{
                            title: '¡Aviso!',
                            text: response.data.message,
                            confirmButtonText: 'Ok',
                            showLoaderOnConfirm: true,
                            preConfirm: () => {
                                window.location.reload();
                            }
                        }])
                    }
                });
          
            } else {
                $scope.closeModal()
               
            }
        });

    }

    // FUNCION DE DESPLIEGA MODAL DE NUEVO ROL
    $scope.addRol = function () {
        $scope.title = "Agregar Rol";
        $scope.isUpdate = false;
        $scope.rol = {};
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/roles/modal.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        });
    }

    // FUNCION DE DESPLIEGA MODAL PARA MODIFICAR ROL
    $scope.modRol = function (item) {
        console.log(item);
        $scope.title = "Modificar Rol";
        $scope.isUpdate = true;
        $scope.rol = item;
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/roles/modal.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        });
    }

     // FUNCION PARA CERRAR VENTA MODAL
    $scope.closeModal = function () {
        $rootScope.modalInstance.close();
    };

    init();
});