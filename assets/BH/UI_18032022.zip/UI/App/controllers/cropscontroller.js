﻿var app = angular.module('app');

app.controller('cropscontroller', function ($scope, $rootScope, $location, authorizationService, unitOfWork, $uibModal) {

    function init() {
       
        $scope.userData = $scope.user.user;
      
        //CARGAR FINCAS SEGUN ROL Y USUARIO
        if ($scope.userData.id_rol == 6 || $scope.userData.id_rol == 5) {
            $scope.getFarmsbyFarms($scope.userData.id_rol, $scope.userData.id);
          
        } else {
            $scope.getFarms();   
        }

        $scope.getCrops();
        $scope.newCrop = {};
        $scope.table1 = true;
        $scope.table2 = false;
        setTimeout(function () { toBase64(); }, 5000);
    }



    $scope.reflesh = function () {
        window.location.reload();
    }

    //LISTA DE FINCAS REGISTRADAS
    $scope.getFarms = function () {
        $scope.listFarms = [];
        unitOfWork.Farms.get(["getFarms"]).then(function (response) {
            $scope.listFarms = response.data.model;
        });
    }

    //LISTA DE FINCAS REGISTRADAS
    $scope.getFarmsbyFarms = function (rol, user) {
        $scope.listFarms = [];
        unitOfWork.Farms.get(["getFarmByRol", rol, user]).then(function (response) {
            $scope.listFarms = response.data.model;
        });
    }

    //LISTA DE CULTIVOS REGISTRADOS 
    $scope.getCrops = function () {
        $scope.listCrops = [];
        unitOfWork.Crops.get(["getCrops"]).then(function (response) {
            $scope.listCrops = response.data.model;
        });
    }

    //LISTA DE CULTIVOS REGISTRADOS - ROL ASOCIADO
    $scope.getmyCrops = function (rol,user) {
        $scope.listCrops = [];
        unitOfWork.Crops.get(["getMyCropFarm",rol,user]).then(function (response) {
            $scope.listCrops = response.data.model;
        });
    }

    //  TRAER INFORMACION DE CULTIVO ESPECICO < SE USA EN VENTA MODAL 
    $scope.getCrop = function (id) {
        var data = id;
        $scope.crops = [];
        unitOfWork.Crops.get(["getCrop",data]).then(function (response) {
            $scope.crops = response.data.model;
            console.log(response.data.model);
        });
    }

     // METODO POST CULTIVO
    $scope.postCrop = function () {
        unitOfWork.Crops.post(["postCrop"], $scope.crops).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        });
         init();
    }

     //METODO UPDATE PARA CULTIVO
    $scope.putCrops = function () {


        unitOfWork.Crops.post(["putCrop"], $scope.crops).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        });
    }

    //METODO DELETE PARA CULTIVO
    $scope.deleteCrops = function (item) {
        Swal.fire({
            title: '¡Aviso!',
            text: 'Desea eliminar este registro?',
            type: 'question',
            confirmButtonText: 'Si, Eliminar',
            confirmButtonColor: '#23B931',
            cancelButtonText: 'Cerrar',
            showCancelButton: true,
            cancelButtonColor: '#dc3545'
        }).then((result) => {
            if (result.value) {
                unitOfWork.Crops.get(["getDestroy", item.id]).then(function (response) {
                    if (!response.data.hasError) {
                        Swal.queue([{
                            title: '¡Aviso!',
                            text: response.data.message,
                            confirmButtonText: 'Ok',
                            showLoaderOnConfirm: true,
                            preConfirm: () => {
                                window.location.reload();
                            }
                        }])

                    }
                });
            
            } else {
                $scope.closeModal()
               
            }
           
        });   
    }
     //MODAL PARA NUEVO CULTIVO
    $scope.addCrops = function () {
        $scope.title = "Agregar Nuevo Cultivo";
        $scope.isUpdate = false;
        $scope.crops = {};
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/crops/editCrop.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        });
    }
     //MODAL PARA MODIFICAR CULTIVO
    $scope.modCrops = function (item) {
        console.log(item);
        $scope.crops = item;
        $scope.title = "Modificar Cultivo";
        $scope.isUpdate = true;
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/crops/editCrop.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        });
    }
/*************************************************************************************************************************************/
    //FUNCIONES PARA MODULO DE REGISTRO DE CULTIVO EN DETERMINADA FINCA


    //FUNCION PARA FILTRAR LISTADO DE CULTIVOS POR FINCA O NIVEL GENERAL
    $scope.Select = function (item) {
    
        $scope.cropsFarm = [];
        if (item == 0) {

            if ($scope.userData.id_rol == 6 || $scope.userData.id_rol == 5) {
                var rol = $scope.userData.id_rol;
                var user = $scope.userData.id;
                unitOfWork.Crops.get(["getMyCropFarm", rol, user]).then(function (response) {
                    $scope.cropsFarm = response.data.model;
                });

            } else {

                unitOfWork.Crops.get(["getCropFarmAll"]).then(function (response) {
                    $scope.cropsFarm = response.data.model;

                });
            }  
            $scope.table1 = true;
            $scope.table2 = false;

        } else {
            unitOfWork.Crops.get(["getCropFarm",item]).then(function (response) {
                $scope.cropsFarm = response.data.model;        
            });  
            $scope.table2 = true;
            $scope.table1 = false;
        }
    }

    //MODAL PARA MODIFICAR CULTIVO
    $scope.modCropFarm = function (item) {
        setTimeout(function () { toBase64(); }, 5000);
        //console.log(item);
        $scope.crops = item;
        $scope.title = "Modificar Cultivo";
        $scope.isUpdate = true;
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/crops/modal.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        });
    }

    //MODAL PARA VER FOTO DE CULTIVO
    $scope.viewPhoto = function (item) {
        $scope.crops = item;
        $scope.title = "Cultivo -" + item.crop +" de " +item.farm;
        $scope.isUpdate = true;
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/crops/viewPhoto.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        });
    }

    // METODO POST PARA REGISTRAR CULTIVO EN UNA FINCA
    $scope.postCropFarm = function () {
        var Crop = {}
        Crop.id_farm = $scope.newCrop.id_farm;
        Crop.id_crop = $scope.newCrop.id_crop ;
        Crop.description = $scope.newCrop.description;
        Crop.photo_path = $scope.fileString;
        $scope.CropData = Crop;
       // console.log($scope.CropData);
        unitOfWork.Crops.post(["postCropFarmWeb"], $scope.CropData).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        });
        init();
    }

    // METODO PUT PARA MODIFICAR INFORMACION DE CULTIVO EN UNA FINCA
    $scope.putCropFarm = function () {
        $scope.crops.opc = 0;

        if (typeof ($scope.fileString) == 'undefined') {
            $scope.crops.opc = 0;
        }

        if (typeof ($scope.fileString) != 'undefined') {
            $scope.crops.photo_path = $scope.fileString;
            $scope.crops.opc = 1;
        }
   
        console.log($scope.crops);
       // console.log($scope.CropData);
        
        unitOfWork.Crops.post(["putCropFarm"], $scope.crops).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        });
       init();
    }
    //METODO DELETE PARA ELIMINAR CULTIVO DE FINCA
    $scope.deleteCropFarm = function (item) {
        Swal.fire({
            title: '¡Aviso!',
            text: 'Desea eliminar este cultivo de '+item.farm+' ?',
            type: 'question',
            confirmButtonText: 'Si, Eliminar',
            confirmButtonColor: '#23B931',
            cancelButtonText: 'Cerrar',
            showCancelButton: true,
            cancelButtonColor: '#dc3545'
        }).then((result) => {
            if (result.value) {
               
                unitOfWork.Crops.get(["getDestroyCrop", item.id]).then(function (response) {
                    if (!response.data.hasError) {
                        Swal.queue([{
                            title: '¡Aviso!',
                            text: response.data.message,
                            confirmButtonText: 'Ok',
                            showLoaderOnConfirm: true,
                            preConfirm: () => {
                                window.location.reload();
                            }
                        }])

                    }
                });

            } else {
                $scope.closeModal()
            }

        });
    }


    //FUNCION PARA CERRAR MODAL
    $scope.closeModal = function () {
        $rootScope.modalInstance.close();
    };



    function toBase64() {
        if (window.File && window.FileReader && window.FileList && window.Blob) {
            if (document.getElementById('file') != null) { 
                document.getElementById('file').addEventListener('change', handleFileSelect, false);
            }
        } else {
            alert('The File APIs are not fully supported in this browser.');
        }

        function handleFileSelect(evt) {
            var f = evt.target.files[0]; // FileList object
            var reader = new FileReader();
            // Closure to capture the file information.
            reader.onload = (function (theFile) {
                return function (e) {
                    var binaryData = e.target.result;
                    //Converting Binary Data to base 64
                    var base64String = window.btoa(binaryData);
                    //showing file converted to base64
                    $scope.fileString = base64String;
                };
            })(f);
            // Read in the image file as a data URL.
            reader.readAsBinaryString(f);
        }
    }

    init();
});