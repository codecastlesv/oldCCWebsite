﻿var app = angular.module('app');

app.controller('loginController', function ($scope, $rootScope, $location, authorizationService) {
    function init() {
        //authorizationService.logout();
        console.log("entra");
    }

    $scope.login = function () {
        if (!$scope.userName || !$scope.password || !$scope.tyc) {
            alert("Usuario, contraseña y la aceptación de nuestros términos y condiciones, son requeridos.");
            return;
        }
        authorizationService.login($scope.userName, $scope.password).then(function (response) {
            if (response.data) {
            
                if (response.data.isAuthenticated) {
                    $rootScope.user = response.data;

                    localStorage.user = JSON.stringify(response.data);
    
                    var url = window.location.protocol + "//" +
                        window.location.host +
                        (window.location.host.indexOf(":") != -1 ? "" : (window.location.port ? ":" + window.location.port : "")) +
                        window.location.pathname;

                    url = url.toUpperCase().split("ACCOUNT")[0].toLocaleLowerCase();
                    url = url + '#!/';
                    window.location.href = url;
                }
                else {
                    Swal.fire({
                        title: '¡Lo sentimos!',
                        text: response.data.message,
                        type: 'warning',
                        confirmButtonText: 'Ok'
                    })
                    $scope.userName = "";
                    $scope.password = "";
                }
            }
            else {

                $scope.userName = "";
                $scope.password = "";
            }
        })
    }

    init();

});