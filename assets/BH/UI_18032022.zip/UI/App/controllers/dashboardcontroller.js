﻿var app = angular.module('app');

app.controller('dashboardcontroller', function ($scope, $rootScope, $location, authorizationService, unitOfWork, $uibModal, leafletData) {

    function init() {
        var id = parseInt(localStorage.getItem("farm"));
        $scope.getData(id);   
        $scope.getusers(id);
        $scope.getFarm(id);
        $scope.getCrops(id);
        $scope.getTask(id);
        $scope.getPlages(id);
        
    }

               
    // FUNCION DE DESPLIEGA MODAL PARA VER USUARIOS ASIGNADOS EN UNA TAREA
    $scope.detail = function (item) {
        $scope.listusersTask = [];
        unitOfWork.Task.get(["getTaskUsers", item.id]).then(function (response) {
            $scope.listusersTask = response.data.model;
        });
        $scope.title = "Tarea:" + item.name;
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/details/task.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        });
    }


    //FUNCION PARA VER INFORMACION DE TAREA COMPLETADA 
    $scope.detailCompleted = function (item) {
        $scope.listDetailsTask = {};
        unitOfWork.Task.get(["getTaskCompleted", item.id]).then(function (response) {
            $scope.listDetailsTask = response.data.model[0];
        });
        $scope.title = "Tarea:" + item.name;
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/details/detailCompleted.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        });
    }




    $scope.view = function (item) {
        $scope.plage = item;
        $scope.title = item.category + " - " + item.plage;
        $scope.isUpdate = true;
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/details/plague.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        });
    }
    
    //LISTA DE PLAGAS 
    $scope.getPlages = function (item) {
        $scope.listPlages = [];
        unitOfWork.DiseasesPlague.get(["getDeseasePlaguefarmAll2", item]).then(function (response) {
            $scope.listPlages = response.data.model;
        });
    }

    //LISTA DE TAREAS 
    $scope.getTask = function (item) {
        $scope.listTask = [];
        unitOfWork.Task.get(["getTask",item]).then(function (response) {
            $scope.listTask = response.data.model;
        });
    }
    //LISTA DE CULTIVOS
    $scope.getCrops = function (item) {
        $scope.cropsFarm = [];
        unitOfWork.Crops.get(["getCropFarm", item]).then(function (response) {
            $scope.cropsFarm = response.data.model;
        });
    }
    $scope.reflesh = function () {
        window.location.reload();
    }

    //FUNCIONA PARA TRAER TODOS LOS USUARIOS COLABORADORES
    $scope.getusers = function (item) {
        $scope.listusers = [];
        unitOfWork.Users.get(["getUserFarm", item]).then(function (response) {
            $scope.listusers = response.data.model;
        });
    }

    //DETALLES DE DATOA DE FINCA
    $scope.getData = function (id) {
        $scope.listData = [];
        unitOfWork.DashboardData.get(["All",id]).then(function (response) {
            $scope.listData = response.data.model;
        });
    }

    //MODAL PARA VER FOTO DE CULTIVO
    $scope.viewPhoto = function (item) {
        $scope.crops = item;
        $scope.title = "Cultivo -" + item.crop + " de " + item.farm;
        $scope.isUpdate = true;
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/details/crop.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        });
    }

  
    $scope.getFarm = function (id) {
        var item = id
        $scope.listFarm = [];
        unitOfWork.Farms.get(["getFarm",item]).then(function (response) {
            $scope.listFarms = response.data.model;
            $scope.farm = $scope.listFarms[0];   

            try {
                var data = JSON.parse($scope.listFarms[0].coordinates);
                $scope.blue = {
                    lat: data.geometry.coordinates[0][0][0],
                    lng: data.geometry.coordinates[0][0][1],
                    zoom: 18
                }
            } catch (error) {
                var data = {}
                /*Swal.queue([{
                    title: '¡Aviso!',
                    text: 'Este Finca no posee coordenadas dibujadas por un usuario',
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                
                    }
                }])*/
            }
         
            $scope.geojson = {
                pointToLayer: function (feature, latlng) {
                    return L.polygon(latlng, {
                        fillColor: 'white',
                        color: 'red',
                    });
                },
                data: {
                    "features": [data]
                }
            };

        });    

        var coordinates = JSON.parse(localStorage.getItem("Coordinates"));

         $scope.loadMap(coordinates.lng, coordinates.lat, coordinates.zoom);
   
    }

    $scope.loadMap = function (latp,lngp,zoomp,data) {
        angular.extend($scope, {
            berlin: {
                lat: latp,
                lng: lngp,
                zoom: zoomp
            },
            controls: {
                draw: {}
            },
            geojson: {
            data: data,
            style: {
                fillColor: "red",
                weight: 2,
                opacity: 1,
                color: 'white',
                dashArray: '3',
                fillOpacity: 0.7
            }
        },
            layers: {
                baselayers: {
                    osm: {
                        name: 'Google-Satellite',
                        url: 'https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}',
                        type: 'xyz'
                    },
                    googleTerrain: {
                        name: 'Google-Map',
                        url: 'https://mt1.google.com/vt/lyrs=r&x={x}&y={y}&z={z}',
                        type: 'xyz'
                    },
                    googleHybrid: {
                        name: 'Google-Hybrid',
                        url: "https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}",
                        type: 'xyz'

                    }

                },
                overlays: {
                    draw: {
                        name: 'draw',
                        type: 'group',
                        visible: true,
                        layerParams: {
                            showOnSelector: false
                        }
                    }
                }
            }

        });

        leafletData.getMap().then(function (map) {
            leafletData.getLayers().then(function (baselayers) {
                var drawnItems = baselayers.overlays.draw;
                map.on('draw:created', function (e) {
                    var layer = e.layer;
                    drawnItems.addLayer(layer);
                    // console.log(JSON.stringify(layer.toGeoJSON()));
                });
            });
        });

    }

    // FUNCION PARA CERRAR VENTA MODAL
    $scope.closeModal = function () {
        $rootScope.modalInstance.close();
    };



    init();
});