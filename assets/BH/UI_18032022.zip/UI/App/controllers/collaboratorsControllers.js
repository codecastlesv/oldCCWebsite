﻿var app = angular.module('app');

app.controller('collaboratoscontroller', function ($scope, $rootScope, $location, authorizationService, unitOfWork, $uibModal) {

    function init() {
      //  $scope.getusers(0);
        $scope.getRoles();
        $scope.userData = $scope.user.user;
        //CARGAR FINCAS SEGUN ROL Y USUARIO
        if ($scope.userData.id_rol == 6 || $scope.userData.id_rol == 5) {

            $scope.getFarmsbyFarms($scope.userData.id_rol, $scope.userData.id);
            $scope.getMyusers($scope.userData.id_rol, $scope.userData.id);

        } else {
            $scope.getFarms();
            $scope.getusers(0);
        }

        $scope.FarmSelect = '';
     
    }

    $scope.reflesh = function () {
        window.location.reload();
    }

    //LISTA DE FINCAS REGISTRADAS
    $scope.getFarms = function () {
        $scope.listFarms = [];
        unitOfWork.Farms.get(["getFarms"]).then(function (response) {
            $scope.listFarms = response.data.model;
        });
    }

    //LISTA DE FINCAS REGISTRADAS
    $scope.getFarmsbyFarms = function (rol, user) {
        $scope.listFarms = [];
        unitOfWork.Farms.get(["getFarmByRol", rol, user]).then(function (response) {
            $scope.listFarms = response.data.model;
        });
    }

    //FUNCIONA PARA TRAER TODOS LOS USUARIOS COLABORADORES
    $scope.getMyusers = function (rol, user) {
        $scope.listusers = [];
        unitOfWork.Users.get(["getUserMyFarm", rol, user]).then(function (response) {
            $scope.listusers = response.data.model;
        });
    }



    //FUNCIONA PARA TRAER TODOS LOS USUARIOS COLABORADORES
    $scope.getusers = function (item) {
        $scope.listusers = [];
        unitOfWork.Users.get(["getUserFarm",item]).then(function (response) {
            $scope.listusers = response.data.model;
        });
    }


    // FUNCION PARA ELIMINA DATOS DE USUARIO COLABORADOR DE UNA FINCA
    $scope.deleteuser = function (item) {
        Swal.fire({
            title: '¡Aviso!',
            text: 'Desea eliminar a '+ item.Name+' ?',
            type: 'question',
            confirmButtonText: 'Si, Eliminar',
            confirmButtonColor: '#23B931',
            cancelButtonText: 'Cerrar',
            showCancelButton: true,
            cancelButtonColor: '#dc3545'
        }).then((result) => {
            if (result.value) {
                unitOfWork.Users.get(["getDestroyUserFarm", item.id_user]).then(function (response) {
                    if (!response.data.hasError) {
                        Swal.queue([{
                            title: '¡Aviso!',
                            text: response.data.message,
                            confirmButtonText: 'Ok',
                            showLoaderOnConfirm: true,
                            preConfirm: () => {
                                window.location.reload();
                            }
                        }])
                    }
                });
              
            } else {
                $scope.closeModal()
               
            }
        });
    }

    // FUNCION QUE DESPLIEGA MODAL PARA NUEVO USUARIO COLABORADOR
    $scope.addusers = function () {
        $scope.title = "Nuevo Colaborador";
        $scope.isUpdate = false;
        $scope.user = {}
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/collaborators/modal.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        })
    }
    // FUNCION QUE DESPLIEGA MODAL PARA MODIFICACION DE INFORMACION DE USUARIO COLABORADOR
    $scope.modusers = function (item) {
        $scope.title = "Modificar información de " + item.Name;
        $scope.isUpdate = true;
        $scope.pass = {};
        $scope.user = item;
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/collaborators/modal.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        });
    }

    //FUNCION PARA CAPTURA FINCA SELECCIONADA 
    $scope.Select = function (item) {
        $scope.FarmSelect = JSON.parse(item);
        console.log($scope.FarmSelect);
    }

    //FUNCION PARA GUARDAR COLABORAR DE UNA FINCA 
    $scope.postCollaborators = function () {
        var data = {}
        data.id_rol = 6;
        data.Name = $scope.user.Name;
        data.Lastname  = $scope.user.Lastname;
        data.dui = $scope.user.dui;
        data.nit = $scope.user.nit;
        data.phone_number = $scope.user.phone_number;
        data.email = $scope.user.email;
        data.password = $scope.user.password;
        data.id_farm = $scope.FarmSelect;
        $scope.collaborator = data;
        unitOfWork.Users.post(["postUserFarm"], $scope.collaborator).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        });
    }


    // FUNCION PARA ACTUALIZAR INFORMACION  DE USUARIO COLABORADOR
    $scope.putCollaborators = function () {

        $scope.aux = $scope.user;
        if (typeof ($scope.pass.passwordOther) != 'undefined') {
            $scope.user.password = $scope.pass.passwordOther;
        }

        if (typeof ($scope.pass.passwordOther) == 'undefined') {
            $scope.user.password = $scope.aux.password;
        } 


        unitOfWork.Users.post(["putUserfarm"], $scope.aux).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        });
    }


    // MODAL PARA AGREGAR OTRA FINCA A UN COLABORADOR
    $scope.addOtherFarm = function (item) {
        $scope.otherAssig = {}
        $scope.otherAssig.id_user = item.id_user;
        $scope.listOtherFarms = [];
        unitOfWork.Farms.get(["myFarmAssig", item.id_user]).then(function (response) {
            $scope.listOtherFarms = response.data.model;
        });
        
        $scope.title = "Agregar otra finca";
        $scope.isUpdate = false;
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/collaborators/addOtherFarm.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        });
    }

    $scope.postOtherFarmColaborator = function () {
        unitOfWork.Farms.post(["addOtherFarm"], $scope.otherAssig).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        });
    }

     //MODAL PARA ELIMINAR UNA FINCA ASIGNADA 
    $scope.MyFarmsAssig = function (item) {

        $scope.listAssigFarm = [];
        unitOfWork.Farms.get(["farmColaborator",item.id_user]).then(function (response) {
            $scope.listAssigFarm = response.data.model;
        });
     
        $scope.title = "Fincas Asignadas";
        $scope.isUpdate = false;
        $scope.user = item;
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/collaborators/DeleteOtherFarm.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        });
    }

    // FUNCION PARA ELIMINAR UNA FINCA ASIGNADA A COLABORADOR
    $scope.deleteAssigmet = function (item) {
        Swal.fire({
            title: '¡Aviso!',
            text: 'Desea eliminar esta asigación',
            type: 'question',
            confirmButtonText: 'Si, Eliminar',
            confirmButtonColor: '#23B931',
            cancelButtonText: 'Cerrar',
            showCancelButton: true,
            cancelButtonColor: '#dc3545'
        }).then((result) => {
            if (result.value) {               
                unitOfWork.Farms.get(["DeleteFarmAssig", item.id]).then(function (response) {
               if (!response.data.hasError) {
                   Swal.queue([{
                       title: '¡Aviso!',
                       text: response.data.message,
                       confirmButtonText: 'Ok',
                       showLoaderOnConfirm: true,
                       preConfirm: () => {
                           window.location.reload();
                       }
                   }])
               }
           });
            } else {

                $scope.closeModal()
              
            
            }
        });
    }


    //FUNCION PARA CERRAR MODAL
    $scope.closeModal = function () {
        $rootScope.modalInstance.close();
    };

    init();
});