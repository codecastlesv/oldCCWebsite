﻿var app = angular.module('app');

app.controller('userscontroller', function ($scope, $rootScope, $location, authorizationService, unitOfWork, $uibModal) {

    function init() {
        $scope.getusers();
        $scope.getRoles();

    }

    $scope.reflesh = function () {
        window.location.reload();
    }

    //FUNCIONA PARA TRAER TODOS LOS USUARIOS
    $scope.getusers = function () {
        $scope.listusers = [];
        unitOfWork.Users.get(["getusers"]).then(function (response) {
            $scope.listusers = response.data.model;
        });
    }

    //FUNCION PARA GUARDAR DATOS DE NUEVO USUARIO
    $scope.postusers = function () {
        unitOfWork.Users.post(["postUser"], $scope.user).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        });
    }
    // FUNCION PARA ACTUALIZAR INFORMACION  DE USUARIO
    $scope.putusers = function () {
        $scope.aux = $scope.user;
        if (typeof ($scope.pass.passwordOther) != 'undefined') {
            $scope.user.password = $scope.pass.passwordOther;
        }

        if (typeof ($scope.pass.passwordOther) == 'undefined') {
            $scope.user.password = $scope.aux.password;         
        } 

        unitOfWork.Users.post(["putUser"], $scope.user).then(function (response) {
            if (!response.data.hasError) {
                Swal.queue([{
                    title: '¡Aviso!',
                    text: response.data.message,
                    confirmButtonText: 'Ok',
                    showLoaderOnConfirm: true,
                    preConfirm: () => {
                        window.location.reload();
                    }
                }])
            }
            else {
                console.log(response);
            }
        });
    }
    // FUNCION PARA ELIMINA DATOS DE USUARIO
    $scope.deleteusers = function (item) {
        Swal.fire({
            title: '¡Aviso!',
            text: 'Desea eliminar este Usuario',
            type: 'question',
            confirmButtonText: 'Si, Eliminar',
            confirmButtonColor: '#23B931',
            cancelButtonText: 'Cerrar',
            showCancelButton: true,
            cancelButtonColor: '#dc3545'
        }).then((result) => {
            if (result.value) {
                unitOfWork.Users.get(["getDestroy", item.id]).then(function (response) {
                    if (!response.data.hasError) {
                        Swal.queue([{
                            title: '¡Aviso!',
                            text: response.data.message,
                            confirmButtonText: 'Ok',
                            showLoaderOnConfirm: true,
                            preConfirm: () => {
                                window.location.reload();
                            }
                        }])
                    }
                });
         
            } else {
                $scope.closeModal()
              
            }
        });
    }

    // FUNCION QUE DESPLIEGA MODAL PARA NUEVO USUARIO
    $scope.addusers = function () {
        $scope.title = "Agregar Usuario";
        $scope.isUpdate = false;
        $scope.user = {}
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/users/modal.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        })
    }
    // FUNCION QUE DESPLIEGA MODAL PARA MODIFICACION DE INFORMACION DE USUARIO
    $scope.modusers = function (item) {
        $scope.title = "Modificar información de " + item.Name ;
        $scope.isUpdate = true;
        $scope.pass = {};
        $scope.user = item;
        $rootScope.modalInstance = $uibModal.open({
            templateUrl: 'app/views/users/modal.html',
            size: 'lg',
            windowClass: 'custom-modal',
            scope: $scope,
            animation: false
        });
    }

    //FUNCION PARA LISTAR TODOS LOS ROLES DISPONIBLES
    $scope.getRoles = function () {
        $scope.listRoles = [];
        unitOfWork.Roles.get(["getRoles"]).then(function (response) {
            $scope.listRoles = response.data.model;
        });
    }

    //FUNCION PARA CERRAR MODAL
    $scope.closeModal = function () {
        $rootScope.modalInstance.close();
    };


   
    init();
});